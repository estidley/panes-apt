#!/usr/bin/env bash
# Add WineHQ official signed repo as EXTRA source; install winehq-stable.
# Never edits Ubuntu security pockets or ubuntu.sources.
set -euo pipefail
FLAG=/var/lib/panes/first-boot-winehq.done
[[ -f "$FLAG" ]] && exit 0
mkdir -p /var/lib/panes /etc/apt/keyrings /etc/apt/sources.list.d
exec > >(tee -a /var/log/panes-first-boot-winehq.log) 2>&1
echo "panes-first-boot-winehq: start $(date -Is)"
export DEBIAN_FRONTEND=noninteractive

. /etc/os-release 2>/dev/null || true
CODENAME="${VERSION_CODENAME:-resolute}"
# WineHQ publishes a suite per Ubuntu release (resolute included); use ours.
WINE_SUITE="$CODENAME"

KEY=/etc/apt/keyrings/winehq-archive.key
need_fetch=1
if [[ -f "$KEY" ]] && grep -q 'BEGIN PGP PUBLIC KEY' "$KEY" 2>/dev/null; then
  need_fetch=0
fi
# Shipped placeholder is not a real key — always fetch official
if [[ -f /usr/share/panes/wine/winehq.key ]] && grep -q 'BEGIN PGP PUBLIC KEY' /usr/share/panes/wine/winehq.key 2>/dev/null; then
  cp /usr/share/panes/wine/winehq.key "$KEY"
  need_fetch=0
fi
if [[ "$need_fetch" -eq 1 ]]; then
  curl -fsSL https://dl.winehq.org/wine-builds/winehq.key -o "$KEY" \
    || wget -qO "$KEY" https://dl.winehq.org/wine-builds/winehq.key \
    || echo "WARN: could not fetch WineHQ key; skipping WineHQ repo"
fi
chmod 644 "$KEY" 2>/dev/null || true

LIST=/etc/apt/sources.list.d/winehq.sources
if [[ ! -f "$LIST" ]] && grep -q 'BEGIN PGP PUBLIC KEY' "$KEY" 2>/dev/null; then
  cat > "$LIST" <<EOF
Types: deb
URIs: https://dl.winehq.org/wine-builds/ubuntu
Suites: ${WINE_SUITE}
Components: main
Architectures: amd64 i386
Signed-By: /etc/apt/keyrings/winehq-archive.key
EOF
  echo "Wrote $LIST (suite=$WINE_SUITE)"
fi

dpkg --add-architecture i386 || true
apt-get update -qq || true

# Prefer winehq-stable over staging: fewer day-to-day regressions for a Win11-feel remix.
if ! dpkg -l winehq-stable 2>/dev/null | grep -q '^ii'; then
  apt-get install -y winehq-stable \
    || apt-get install -y wine-stable \
    || echo "WineHQ stable unavailable for $WINE_SUITE; keeping distro wine"
fi

# Pin lightly: prefer WineHQ wine* but never pin Ubuntu security packages
cat > /etc/apt/preferences.d/panes-winehq <<'PIN'
Package: winehq-stable wine-stable*
Pin: release o=dl.winehq.org
Pin-Priority: 700

Package: *
Pin: release o=Ubuntu
Pin-Priority: 500
PIN

touch "$FLAG"
echo "panes-first-boot-winehq: done $(date -Is)"
