# panes-wine

- **WineHQ stable** is added as an *extra* signed apt source on first boot
  (`/etc/apt/sources.list.d/winehq.sources`). Ubuntu `ubuntu.sources` and
  security pockets are never edited.
- **Why stable vs staging:** staging tracks upstream more aggressively and
  regresses desktop apps more often; Panes defaults to stable for a
  Windows-feel daily driver. Testers can install `winehq-staging` manually.
- **UAC:** `panes-uac` is cosmetic consent before setup.exe/.msi.
- **Quiet:** `WINEDEBUG=-all`; no terminal windows from the MIME handler.
- **Red-team pinning:** Pin-Priority 700 for WineHQ wine packages only; Ubuntu
  security updates stay at default. If WineHQ lags a CVE, distro `wine64`
  remains installable as fallback (`Depends: wine64 | wine | winehq-stable`).
