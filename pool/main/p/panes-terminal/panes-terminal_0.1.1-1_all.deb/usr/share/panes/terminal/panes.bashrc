# Panes bash profile: Windows drive letters in bash (Command shell profile).
[ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
[ -f "$HOME/.bashrc" ] && . "$HOME/.bashrc"
command -v panes-winpath >/dev/null && panes-winpath --setup >/dev/null 2>&1
# cd C:\Users\me, cd D:\photos, cd "Z:\etc" all work.
cd() {
  if [ $# -ge 1 ] && [[ "$1" =~ ^[A-Za-z]: ]]; then
    local t; t="$(panes-winpath -u "$1")" || { echo "cd: cannot find path '$1' because it does not exist." >&2; return 1; }
    builtin cd "$t"
  else
    builtin cd "$@"
  fi
}
# Typing a drive letter by itself switches drive, like cmd/PowerShell.
for __l in {A..Z}; do eval "${__l}:() { cd ${__l}:\\\\; }"; eval "${__l,,}:() { cd ${__l}:\\\\; }"; done; unset __l
cls() { clear; }
dir() { ls -la "$@"; }
__panes_pwd() { panes-winpath "$PWD" 2>/dev/null || printf '%s' "$PWD"; }
PS1='$(__panes_pwd)> '
