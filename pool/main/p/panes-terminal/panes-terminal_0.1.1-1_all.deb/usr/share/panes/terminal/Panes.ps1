# Panes PowerShell profile: Windows drive letters inside pwsh on Panes.
# C:\ is the Panes C: view (C:\Users\<you> = your home), D:..Y: are the drive
# letters from This PC, Z:\ is the whole Linux filesystem (like Wine).
$ErrorActionPreference = 'SilentlyContinue'
$PanesCView = Join-Path $HOME '.local/share/panes/c-drive'
if (Get-Command panes-winpath -ErrorAction SilentlyContinue) { panes-winpath --setup | Out-Null }
$prefix = if ($env:PANES_WINEPREFIX) { $env:PANES_WINEPREFIX } else { Join-Path $HOME '.local/share/panes/prefixes/default' }
function Add-PanesDrive([string]$Letter, [string]$Root) {
    if (-not (Test-Path -LiteralPath $Root)) { return }
    if (Get-PSDrive -Name $Letter -ErrorAction SilentlyContinue) { Remove-PSDrive -Name $Letter -Force }
    New-PSDrive -Name $Letter -PSProvider FileSystem -Root $Root -Scope Global | Out-Null
}
function Update-PanesDrives {
    Add-PanesDrive 'C' $PanesCView
    Add-PanesDrive 'Z' '/'
    $dos = Join-Path $prefix 'dosdevices'
    if (Test-Path $dos) {
        Get-ChildItem -LiteralPath $dos | Where-Object { $_.Name -match '^[a-y]:$' -and $_.Name -ne 'c:' } | ForEach-Object {
            $t = $_.Target; if ($t -is [array]) { $t = $t[0] }
            if ($t) { Add-PanesDrive ($_.Name.Substring(0,1).ToUpper()) $t }
        }
    }
}
Update-PanesDrives
# Typing D: switches drive, as on Windows (pwsh on Linux has no such functions).
foreach ($l in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') {
    Set-Item -Path "function:global:${l}:" -Value ([scriptblock]::Create("Set-Location ${l}:\"))
}
# Show C:\Users\<you> instead of /home/<you> when outside a lettered drive.
function global:prompt {
    $p = $ExecutionContext.SessionState.Path.CurrentLocation
    $shown = if ($p.Drive -and $p.Drive.Name -match '^[A-Z]$') { $p.Path.Replace('/', '\') }
             elseif ($p.Path -eq $HOME -or $p.Path.StartsWith("$HOME/")) {
                 'C:\Users\' + [Environment]::UserName + $p.Path.Substring($HOME.Length).Replace('/', '\') }
             else { 'Z:' + $p.Path.Replace('/', '\') }
    "PS $shown> "
}
# Windows-familiar commands that pwsh on Linux leaves out.
Set-Alias -Name ls -Value Get-ChildItem -Scope Global -Option AllScope -Force
function global:ipconfig { if (Get-Command ip -EA 0) { ip -brief address } }
function global:explorer([string]$Path = '.') { Start-Process panes-explorer -ArgumentList (Resolve-Path $Path).ProviderPath }
function global:notepad([string]$Path) { if ($Path) { Start-Process kwrite $Path } else { Start-Process kwrite } }
if ((Get-Location).Path -eq $HOME) { Set-Location "C:\Users\$([Environment]::UserName)" }
$ErrorActionPreference = 'Continue'
