[Appearance]
ColorScheme=Panes
Font=Liberation Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Command=/usr/bin/panes-terminal --shell bash
Icon=utilities-terminal
LocalTabTitleFormat=%n
Name=Command shell
Parent=FALLBACK/
TerminalMargin=8

[Scrolling]
HistoryMode=2

[Terminal Features]
BlinkingCursorEnabled=true
