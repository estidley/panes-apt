#!/usr/bin/env bash
# Add Microsoft's signed Linux repo as an EXTRA source and install PowerShell 7.
# Same model as WineHQ: never edits ubuntu.sources or Ubuntu security pockets;
# pinned so only the powershell package can come from it.
set -euo pipefail
FLAG=/var/lib/panes/first-boot-pwsh.done
[[ -f "$FLAG" ]] && exit 0
command -v pwsh >/dev/null && { mkdir -p /var/lib/panes; touch "$FLAG"; exit 0; }
mkdir -p /var/lib/panes /etc/apt/keyrings /etc/apt/sources.list.d /etc/apt/preferences.d
exec > >(tee -a /var/log/panes-first-boot-pwsh.log) 2>&1
echo "panes-first-boot-pwsh: start $(date -Is)"
export DEBIAN_FRONTEND=noninteractive
. /etc/os-release 2>/dev/null || true
KEY=/etc/apt/keyrings/microsoft.asc
curl -fsSL https://packages.microsoft.com/keys/microsoft.asc -o "$KEY.tmp" && mv "$KEY.tmp" "$KEY" \
  || { echo "WARN: no Microsoft key; will retry next boot"; exit 0; }
chmod 644 "$KEY"
# Microsoft publishes per-version suites; newest LTS can lag, so fall back.
SUITE=""
for v in "${VERSION_ID:-26.04}" 24.04; do
  if curl -fsI "https://packages.microsoft.com/ubuntu/$v/prod/dists/" >/dev/null 2>&1 \
     || curl -fsI "https://packages.microsoft.com/ubuntu/$v/prod/" >/dev/null 2>&1; then
    SUITE="$v"; break
  fi
done
[[ -n "$SUITE" ]] || { echo "WARN: Microsoft repo unreachable; retry next boot"; exit 0; }
case "$SUITE" in 26.04) CODE="${VERSION_CODENAME:-resolute}";; 24.04) CODE=noble;; esac
cat > /etc/apt/sources.list.d/microsoft-prod.sources <<SRC
Types: deb
URIs: https://packages.microsoft.com/ubuntu/$SUITE/prod
Suites: $CODE
Components: main
Architectures: amd64
Signed-By: $KEY
SRC
cat > /etc/apt/preferences.d/panes-microsoft <<'PIN'
# Only PowerShell may come from Microsoft's repo.
Package: *
Pin: origin packages.microsoft.com
Pin-Priority: 1

Package: powershell
Pin: origin packages.microsoft.com
Pin-Priority: 500
PIN
apt-get update -qq || true
if apt-get install -y powershell; then
  touch "$FLAG"
else
  echo "WARN: powershell install failed; Terminal falls back to bash. Retry next boot."
fi
echo "panes-first-boot-pwsh: done $(date -Is)"
