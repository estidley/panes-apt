/* Panes installer slideshow (original text and art). */
import QtQuick 2.0
import calamares.slideshow 1.0

Presentation {
    id: presentation
    function nextSlide() { presentation.goToNextSlide() }
    Timer { interval: 12000; running: presentation.activatedInCalamares; repeat: true; onTriggered: nextSlide() }

    Repeater {
        model: [
            ["Hi.", "We're getting everything ready for you. This will take a few minutes."],
            ["Your Windows apps, welcome here", "Double-click a setup.exe and Panes installs it like you're used to."],
            ["Get more apps", "Pane Store has thousands of apps, installed and updated for you."],
            ["Protected from the start", "Pane Defender scans for threats and keeps your firewall on."],
            ["Files where you expect them", "File Explorer shows C:\\Users, drive letters and This PC."],
            ["Almost there", "Don't turn off your PC."]
        ]
        Slide {
            Rectangle {
                anchors.fill: parent
                gradient: Gradient {
                    GradientStop { position: 0.0; color: "#0b1d4a" }
                    GradientStop { position: 1.0; color: "#1b4fa8" }
                }
                Column {
                    anchors.centerIn: parent
                    spacing: 18
                    width: parent.width * 0.8
                    Text { text: modelData[0]; color: "white"; font.pixelSize: 34; font.weight: Font.Light
                           horizontalAlignment: Text.AlignHCenter; width: parent.width; wrapMode: Text.WordWrap }
                    Text { text: modelData[1]; color: "#d6e6ff"; font.pixelSize: 17
                           horizontalAlignment: Text.AlignHCenter; width: parent.width; wrapMode: Text.WordWrap }
                }
            }
        }
    }
    function onActivate() { presentation.currentSlide = 0 }
    function onLeave() { }
}
