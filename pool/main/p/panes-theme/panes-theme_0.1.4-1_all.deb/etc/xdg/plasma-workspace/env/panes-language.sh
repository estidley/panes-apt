# Panes: for English sessions, look in the "en@panes" catalogs first so the
# taskbar jump list uses Win11 wording ("Pin to taskbar", "Close window").
# Untouched when the user picked a non-English language or set LANGUAGE.
case "${LANG:-}" in
    en*|C.UTF-8|"")
        if [ -z "${LANGUAGE:-}" ]; then
            base="${LANG%%.*}"; [ -n "$base" ] && [ "$base" != C ] || base=en_US
            export LANGUAGE="en@panes:$base:en"
        fi ;;
esac
