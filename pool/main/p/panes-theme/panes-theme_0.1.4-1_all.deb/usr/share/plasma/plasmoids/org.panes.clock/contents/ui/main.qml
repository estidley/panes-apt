// Panes clock: two-line time/date on the taskbar; click (or Win+N) opens
// one flyout with Notifications on top and the Calendar below, like Win11.
// Backends: Plasma's notification server history (NotificationManager)
// and Plasma's calendar (incl. holiday/event plugins the user enables).
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasma5support as P5Support
import org.kde.notificationmanager as NotificationManager
import org.kde.plasma.workspace.calendar as PlasmaCalendar

PlasmoidItem {
    id: root
    property date now: new Date()
    property bool use24: Plasmoid.configuration.use24hFormat === 2

    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.now = new Date() }

    P5Support.DataSource {
        id: exec; engine: "executable"; connectedSources: []
        onNewData: (source) => disconnectSource(source)
    }
    function run(cmd) { exec.connectSource(cmd) }

    NotificationManager.Settings { id: notifySettings }
    NotificationManager.Notifications {
        id: history
        showExpired: true
        showDismissed: true
        showJobs: false
        sortMode: NotificationManager.Notifications.SortByDate
        groupMode: NotificationManager.Notifications.GroupDisabled
    }
    readonly property bool dnd: notifySettings.notificationsInhibitedUntil > new Date()

    toolTipMainText: Qt.formatDate(now, "dddd, MMMM d, yyyy")
    toolTipSubText: ""

    compactRepresentation: MouseArea {
        Layout.minimumWidth: col.implicitWidth + Kirigami.Units.largeSpacing * 2
        hoverEnabled: true
        onClicked: root.expanded = !root.expanded
        Rectangle {
            anchors.fill: parent; anchors.margins: 3; radius: 4
            color: parent.containsMouse || root.expanded ? Qt.rgba(0.5, 0.5, 0.5, 0.18) : "transparent"
        }
        ColumnLayout {
            id: col
            anchors.centerIn: parent
            spacing: 0
            PC3.Label {
                Layout.alignment: Qt.AlignRight
                text: Qt.formatTime(root.now, root.use24 ? "HH:mm" : "h:mm AP")
            }
            PC3.Label {
                Layout.alignment: Qt.AlignRight
                text: Qt.formatDate(root.now, Qt.locale().dateFormat(Locale.ShortFormat))
            }
        }
        Rectangle {  // unread badge, like Win11's notification count
            visible: history.count > 0 && !root.expanded
            anchors { right: parent.right; top: parent.top; margins: 2 }
            width: Kirigami.Units.gridUnit * 0.9; height: width; radius: width / 2
            color: Kirigami.Theme.highlightColor
            PC3.Label {
                anchors.centerIn: parent; font.pixelSize: parent.height * 0.65
                text: history.count > 9 ? "9+" : history.count
                color: Kirigami.Theme.highlightedTextColor
            }
        }
    }

    fullRepresentation: ColumnLayout {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 22
        Layout.preferredHeight: Kirigami.Units.gridUnit * 36
        spacing: Kirigami.Units.largeSpacing

        // ---- Notifications ------------------------------------------
        RowLayout {
            Kirigami.Heading { level: 4; text: "Notifications"; Layout.fillWidth: true }
            PC3.ToolButton {
                icon.name: root.dnd ? "notifications-disabled" : "notifications"
                checkable: true; checked: root.dnd
                PC3.ToolTip { text: "Do not disturb" }
                onClicked: {
                    var d = new Date();
                    notifySettings.notificationsInhibitedUntil = root.dnd ? d : new Date(d.getTime() + 24 * 3600 * 1000);
                    notifySettings.save();
                }
            }
            PC3.Button {
                text: "Clear all"; visible: history.count > 0
                onClicked: history.clear(NotificationManager.Notifications.ClearExpired)
            }
        }
        QQC2.ScrollView {
            Layout.fillWidth: true; Layout.fillHeight: true
            ListView {
                id: list
                model: history
                spacing: Kirigami.Units.smallSpacing
                clip: true
                delegate: Rectangle {
                    width: ListView.view.width
                    height: body.implicitHeight + Kirigami.Units.largeSpacing * 2
                    radius: 6
                    color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.06)
                    RowLayout {
                        id: body
                        anchors { fill: parent; margins: Kirigami.Units.largeSpacing }
                        Kirigami.Icon { source: model.applicationIconName || "preferences-desktop-notification"; Layout.preferredWidth: Kirigami.Units.iconSizes.medium; Layout.preferredHeight: Layout.preferredWidth; Layout.alignment: Qt.AlignTop }
                        ColumnLayout {
                            Layout.fillWidth: true; spacing: 0
                            PC3.Label { text: model.applicationName || ""; opacity: 0.7; font.pointSize: Kirigami.Theme.smallFont.pointSize }
                            PC3.Label { text: model.summary || ""; font.bold: true; Layout.fillWidth: true; elide: Text.ElideRight }
                            PC3.Label { text: model.body || ""; Layout.fillWidth: true; wrapMode: Text.Wrap; maximumLineCount: 3; textFormat: Text.StyledText }
                        }
                        PC3.ToolButton {
                            icon.name: "window-close"; Layout.alignment: Qt.AlignTop
                            onClicked: history.close(history.index(index, 0))
                        }
                    }
                }
                PC3.Label {
                    anchors.centerIn: parent; visible: list.count === 0
                    text: "No new notifications"; opacity: 0.7
                }
            }
        }

        Kirigami.Separator { Layout.fillWidth: true }

        // ---- Calendar -----------------------------------------------
        Kirigami.Heading { level: 4; text: Qt.formatDate(root.now, "dddd, MMMM d") }
        PlasmaCalendar.MonthView {
            Layout.fillWidth: true
            Layout.preferredHeight: Kirigami.Units.gridUnit * 14
            today: root.now
            showWeekNumbers: false
        }
    }

    Plasmoid.contextualActions: [
        PlasmaCore.Action {
            text: "Adjust date and time"; icon.name: "preferences-system-time"
            onTriggered: root.run("panes-settings time")
        },
        PlasmaCore.Action {
            text: "Notification settings"; icon.name: "preferences-desktop-notification"
            onTriggered: root.run("panes-settings system notifications")
        },
        PlasmaCore.Action {
            text: "Taskbar settings"; icon.name: "configure"
            onTriggered: root.run("panes-settings personalization taskbar")
        }
    ]
}
