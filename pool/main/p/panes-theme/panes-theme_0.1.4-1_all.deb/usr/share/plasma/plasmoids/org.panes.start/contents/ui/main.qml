// Panes Start button. Click, or the Win key (Plasma routes Meta to the
// applet that provides org.kde.plasma.launchermenu), toggles panes-start.
import QtQuick
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasma5support as P5Support

PlasmoidItem {
    id: root
    preferredRepresentation: compactRepresentation
    Plasmoid.icon: "panes-start"
    toolTipMainText: "Start"
    toolTipSubText: ""

    P5Support.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source) => disconnectSource(source)
    }
    function run(cmd) { exec.connectSource(cmd) }

    Connections {
        target: Plasmoid
        function onActivated() { root.run("panes-start") }
    }

    compactRepresentation: MouseArea {
        hoverEnabled: true
        onClicked: root.run("panes-start")
        Rectangle {
            anchors.fill: parent; anchors.margins: 3; radius: 4
            color: parent.containsMouse ? Qt.rgba(0.5, 0.5, 0.5, 0.18) : "transparent"
        }
        Kirigami.Icon {
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height) * 0.62; height: width
            source: "panes-start"
            fallback: "start-here-kde"
        }
    }

    Plasmoid.contextualActions: [
        PlasmaCore.Action {
            text: "Taskbar settings"; icon.name: "configure"
            onTriggered: root.run("panes-settings personalization taskbar")
        },
        PlasmaCore.Action {
            text: "Settings"; icon.name: "preferences-system"
            onTriggered: root.run("panes-settings")
        },
        PlasmaCore.Action {
            text: "File Explorer"; icon.name: "system-file-manager"
            onTriggered: root.run("panes-explorer")
        },
        PlasmaCore.Action {
            text: "Task Manager"; icon.name: "utilities-system-monitor"
            onTriggered: root.run("plasma-systemmonitor")
        }
    ]
}
