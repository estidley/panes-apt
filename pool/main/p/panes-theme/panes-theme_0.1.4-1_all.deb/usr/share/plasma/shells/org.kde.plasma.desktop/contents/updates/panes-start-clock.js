// Panes: swap stock Kickoff -> Panes Start and Digital Clock -> Panes clock
// (calendar + notifications flyout) on existing panels, keeping position.
// Plasma runs each update script once per user.
function swap(p, oldPlugin, newPlugin, setup) {
    p.widgets(oldPlugin).forEach(function (old) {
        p.currentConfigGroup = ["General"];
        var order = String(p.readConfig("AppletOrder", "")).split(";");
        var w = p.addWidget(newPlugin);
        if (setup) setup(w);
        var pos = order.indexOf(String(old.id));
        if (pos >= 0) {
            order[pos] = String(w.id);
            p.writeConfig("AppletOrder", order.join(";"));
        }
        old.remove();
    });
}
panels().forEach(function (p) {
    swap(p, "org.kde.plasma.kickoff", "org.panes.start");
    swap(p, "org.kde.plasma.kicker", "org.panes.start");
    swap(p, "org.kde.plasma.digitalclock", "org.panes.clock", function (w) {
        w.globalShortcut = "Meta+N";
    });
    if (p.reloadConfig) p.reloadConfig();
});
