// Panes: full-width Win11 taskbar. Empty space on either side of the
// centered Start/tasks group is a Panes "Taskbar space" filler whose
// right-click menu is just "Taskbar settings". Runs once per user.
panels().forEach(function (p) {
    if (p.location !== "bottom" || p.widgets("org.panes.start").length === 0) return;
    if (p.widgets("org.panes.taskbarmenu").length > 0) return;
    p.currentConfigGroup = ["General"];
    var order = String(p.readConfig("AppletOrder", "")).split(";").filter(function (s) { return s; });
    var start = p.widgets("org.panes.start")[0];
    var tasks = p.widgets("org.kde.plasma.icontasks");
    var lead = p.addWidget("org.panes.taskbarmenu");
    var trail = p.addWidget("org.panes.taskbarmenu");
    order = order.filter(function (id) { return id !== String(lead.id) && id !== String(trail.id); });
    var s = order.indexOf(String(start.id));
    if (s >= 0) order.splice(s, 0, String(lead.id));
    var after = tasks.length ? order.indexOf(String(tasks[0].id)) : order.indexOf(String(start.id));
    if (after >= 0) order.splice(after + 1, 0, String(trail.id));
    p.writeConfig("AppletOrder", order.join(";"));
    p.lengthMode = "fill";
    if (p.reloadConfig) p.reloadConfig();
});
locked = true;
