var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [],
            "config": {
                "/": {
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0"
                },
                "/General": {
                    "ToolBoxButtonState": "bottom"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "height": 48,
            "hiding": "normal",
            "lengthMode": "fill",
            "location": "bottom",
            "maximumLength": 1600,
            "minimumLength": 560,
            "offset": 0,
            "opacity": "adaptive",
            "applets": [
                {
                    "plugin": "org.panes.taskbarmenu"
                },
                {
                    "plugin": "org.panes.start"
                },
                {
                    "plugin": "org.kde.plasma.icontasks",
                    "config": {
                        "/General": {
                            "launchers": "applications:panes-search.desktop,applications:panes-task-view.desktop,applications:panes-settings.desktop,applications:panes-explorer.desktop,applications:firefox.desktop,applications:panes-store.desktop,applications:panes-terminal.desktop",
                            "showToolTips": "true",
                            "highlightWindows": "true",
                            "indicateAudioStreams": "true"
                        }
                    }
                },
                {
                    "plugin": "org.panes.taskbarmenu"
                },
                {
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "plugin": "org.panes.clock"
                }
            ]
        }
    ]
};

plasma.loadSerializedLayout(layout);

// Lock the taskbar so empty space offers only "Taskbar settings" (Win11).
locked = true;

// Win+N opens the clock's notifications + calendar flyout (Win11).
panels().forEach(function (p) {
    p.widgets("org.panes.clock").forEach(function (w) { w.globalShortcut = "Meta+N"; });
});

// Panes wallpaper (panes-branding) when installed.
desktops().forEach(function (d) {
    d.wallpaperPlugin = "org.kde.image";
    d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    d.writeConfig("Image", "file:///usr/share/wallpapers/Panes/");
});
