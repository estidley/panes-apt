// Panes taskbar space: an invisible expanding filler. Like Win11, a
// right-click on empty taskbar space offers only "Taskbar settings".
// Plasma's own panel/widget items are hidden while the panel is locked.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as P5Support

PlasmoidItem {
    id: root
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    Plasmoid.constraintHints: Plasmoid.CanFillArea
    preferredRepresentation: fullRepresentation
    Layout.fillWidth: true
    Layout.fillHeight: true
    Layout.minimumWidth: 1
    Layout.preferredWidth: 1

    P5Support.DataSource {
        id: exec; engine: "executable"; connectedSources: []
        onNewData: (source) => disconnectSource(source)
    }

    Plasmoid.contextualActions: [
        PlasmaCore.Action {
            text: "Taskbar settings"
            icon.name: "configure"
            onTriggered: exec.connectSource("panes-settings personalization taskbar")
        }
    ]

    Component.onCompleted: {
        ["configure", "remove", "alternatives"].forEach(function (n) {
            var a = Plasmoid.internalAction(n);
            if (a) a.visible = false;
        });
    }

    fullRepresentation: Item {}
}
