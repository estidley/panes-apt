# Fonts

Panes depends on **Inter**, **Liberation Sans**, and **Noto** from Ubuntu archives (metric-friendly free fonts).

**Selawik** (OFL Segoe UI stand-in) is recommended but not bundled as a binary in this MVP to keep the package small. To install Selawik manually:

1. Download OFL Selawik from a trusted OFL redistributor or the upstream Selawik project.
2. Copy `.ttf` files to `~/.local/share/fonts/` or `/usr/local/share/fonts/`.
3. Run `fc-cache -f`.
4. Set UI font to Selawik in System Settings → Fonts (or re-run `/usr/lib/panes/apply-theme.sh --selawik`).

Never install Microsoft Segoe UI or other proprietary Windows fonts into Panes packages.
