#!/usr/bin/env bash
# Apply Panes look-and-feel for the current user (run as the desktop user, not root).
set -euo pipefail
LOOK=org.panes.desktop
NO_LAYOUT=0
for a in "$@"; do [[ "$a" == "--no-layout" ]] && NO_LAYOUT=1; done
if [[ "$NO_LAYOUT" -eq 0 ]] && command -v lookandfeeltool >/dev/null 2>&1; then
  lookandfeeltool -a "$LOOK" || lookandfeeltool --apply "$LOOK" || true
fi
# Prefer Selawik if present, else Inter
FONT=Inter
if fc-list | grep -qi selawik; then
  FONT=Selawik
fi
for a in "$@"; do [[ "$a" == "--selawik" ]] && FONT=Selawik; done
kwriteconfig5 --file kdeglobals --group General --key font "${FONT},10,-1,5,50,0,0,0,0,0" 2>/dev/null || true
kwriteconfig6 --file kdeglobals --group General --key font "${FONT},10,-1,5,50,0,0,0,0,0" 2>/dev/null || true
# KWin motion-ish defaults
for f in kwriteconfig5 kwriteconfig6; do
  command -v $f >/dev/null || continue
  $f --file kwinrc --group Plugins --key blurEnabled true
  $f --file kwinrc --group Plugins --key kwin4_effect_fadeEnabled true
  $f --file kwinrc --group Plugins --key kwin4_effect_scaleEnabled true
  $f --file kwinrc --group Plugins --key slidingpopupsEnabled true
  $f --file kwinrc --group Plugins --key squashEnabled true
done
echo "Panes theme apply attempted (font=$FONT). Log out/in if the panel did not update."
