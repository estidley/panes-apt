#!/usr/bin/env bash
set -euo pipefail
# Win-like shortcuts and shell bindings (best-effort; Plasma versions vary)
set_kw() {
  local file="$1" group="$2" key="$3" value="$4"
  if command -v kwriteconfig6 >/dev/null; then
    kwriteconfig6 --file "$file" --group "$group" --key "$key" "$value" || true
  elif command -v kwriteconfig5 >/dev/null; then
    kwriteconfig5 --file "$file" --group "$group" --key "$key" "$value" || true
  fi
}
set_kw kwinrc Windows BorderlessMaximizedWindows false
set_kw kdeglobals KDE SingleClick false

# Meta+Tab → Overview / Task View
set_kw kglobalshortcutsrc kwin "ExposeAll" "Meta+Tab,none,Toggle Overview"
set_kw kglobalshortcutsrc kwin "Overview" "Meta+Tab,none,Toggle Overview"

mkdir -p "$HOME/.config" "$HOME/.local/share/applications" "$HOME/.config/autostart"

if command -v kwriteconfig6 >/dev/null; then
  # Win+A Quick Settings
  kwriteconfig6 --file kglobalshortcutsrc --group "panes-quick-settings.desktop" \
    --key "_launch" "Meta+A,none,Quick settings" || true
  # Win+N Notification Center
  # Win+N belongs to the Panes clock flyout (set in the panel layout).
  kwriteconfig6 --file kglobalshortcutsrc --group "panes-notifications.desktop" \
    --key "_launch" "none,none,Notification center" || true
  # Win+S Search (KRunner often already Meta+Space)
  kwriteconfig6 --file kglobalshortcutsrc --group "panes-search.desktop" \
    --key "_launch" "Meta+S,none,Search" || true
fi

# Double-clicking a disc image mounts it as a DVD drive letter (Win11).
if command -v xdg-mime >/dev/null; then
  for m in application/x-cd-image application/x-iso9660-image application/vnd.efi.iso; do
    xdg-mime default panes-mount-iso.desktop "$m" || true
  done
fi

# Optional: bind desktop right-click helper via custom mouse shortcut note
cat > "$HOME/.config/panes-win-shortcuts.conf" <<'EOF'
# Panes Win-key map
# Meta          → Kickoff / Start (Plasma default)
# Meta+A        → panes-quick-settings
# Meta+N        → Panes clock flyout (notifications + calendar); was panes-notification-center
# Meta+S        → Search (KRunner via panes-search)
# Meta+Tab      → Overview (Task View)
# Desktop menu  → run panes-desktop-menu (bind mouse if Plasma menu still shows)
EOF

echo "Panes defaults applied for $USER"
