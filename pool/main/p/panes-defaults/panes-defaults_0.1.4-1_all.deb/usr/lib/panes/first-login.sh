#!/usr/bin/env bash
# Once per user: apply Panes theme settings and Win-key defaults on first sign-in.
# The Panes layout itself comes from the system-wide LookAndFeelPackage, so the
# theme step skips lookandfeeltool (it would reset an existing user's taskbar).
set -u
[ "$(id -u)" -eq 0 ] && exit 0
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/panes"
FLAG="$STATE/first-login-v1.done"
[ -f "$FLAG" ] && exit 0
mkdir -p "$STATE"
{
  echo "panes first-login: $(date -Is)"
  [ -f /usr/lib/panes/apply-theme.sh ] && bash /usr/lib/panes/apply-theme.sh --no-layout
  [ -f /usr/lib/panes/apply-defaults.sh ] && bash /usr/lib/panes/apply-defaults.sh
  # Pick up KWin changes in this session.
  if command -v qdbus6 >/dev/null; then qdbus6 org.kde.KWin /KWin reconfigure || true
  elif command -v qdbus >/dev/null; then qdbus org.kde.KWin /KWin reconfigure || true; fi
} >>"$STATE/first-login.log" 2>&1
touch "$FLAG"
exit 0
