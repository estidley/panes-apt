"""Bluetooth & devices sub-pages: Mouse, Touchpad, Printers & scanners, AutoPlay.

Mouse/touchpad talk to KWin's input devices over D-Bus; KWin applies the
change at once and saves it itself (kcminputrc). Printers use CUPS (lpstat/lpadmin,
driverless IPP Everywhere). AutoPlay writes the same drives.json keys the
Panes drive service reads.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from .ui import *  # noqa: F401,F403
from .ui import QT6, Qt, Page, Toggle, run, out, have, kwrite, kread, elevate

KWIN = "org.kde.KWin"
DEV_PATH = "/org/kde/KWin/InputDevice"
IFACE = "org.kde.KWin.InputDevice"


def _busctl(*args):
    return run(["busctl", "--user", *args])


def _prop(sysname, name):
    r = _busctl("get-property", KWIN, f"{DEV_PATH}/{sysname}", IFACE, name)
    if not r or r.returncode != 0:
        return None
    parts = r.stdout.strip().split(" ", 1)
    if len(parts) < 2:
        return None
    t, v = parts
    if t == "b":
        return v == "true"
    if t in ("d",):
        return float(v)
    if t in ("u", "i"):
        return int(v)
    if t == "s":
        return v.strip('"')
    return v


def _set(sysname, name, typ, value):
    v = ("true" if value else "false") if typ == "b" else str(value)
    r = _busctl("set-property", KWIN, f"{DEV_PATH}/{sysname}", IFACE, name, typ, v)
    return bool(r and r.returncode == 0)


def input_devices(kind):
    """kind: 'pointer' (mice) or 'touchpad'."""
    r = _busctl("get-property", KWIN, "/org/kde/KWin/InputDevice", "org.kde.KWin.InputDeviceManager",
                "devicesSysNames")
    if not r or r.returncode != 0:
        return []
    names = [x.strip('"') for x in r.stdout.split()[2:]]
    found = []
    for n in names:
        is_tp = _prop(n, "touchpad")
        if kind == "touchpad" and is_tp:
            found.append(n)
        elif kind == "pointer" and _prop(n, "pointer") and not is_tp:
            found.append(n)
    return found


class _InputPage(Page):
    KIND = "pointer"
    TITLE = "Mouse"

    def __init__(self):
        super().__init__(f"Bluetooth & devices  ›  {self.TITLE}")
        self.devs = input_devices(self.KIND) if have("busctl") else []
        if not self.devs:
            self.note(f"No {self.TITLE.lower()} found." if self.KIND == "touchpad"
                      else "No mouse found. Plug one in or turn on Bluetooth.")
            self.finish(); return
        d0 = self.devs[0]
        self.build(d0)
        self.finish()

    def apply(self, prop, typ, value, _key=None):
        for d in self.devs:
            _set(d, prop, typ, value)

    def speed_slider(self, d0):
        s = QSlider(Qt.Orientation.Horizontal if QT6 else Qt.Horizontal)
        s.setRange(-100, 100); s.setFixedWidth(220)
        s.setValue(int((_prop(d0, "pointerAcceleration") or 0) * 100))
        s.valueChanged.connect(lambda v: self.apply("pointerAcceleration", "d", round(v / 100, 2), "PointerAcceleration"))
        return s

    def toggle(self, d0, prop, key, title, desc=""):
        sup = {"tapToClick": "tapFingerCount", "tapAndDrag": "tapFingerCount"}.get(prop)
        if sup and not _prop(d0, sup):
            return
        if not sup and _prop(d0, "supports" + prop[0].upper() + prop[1:]) is False:
            return
        t = Toggle(bool(_prop(d0, prop)))
        t.toggled.connect(lambda on: self.apply(prop, "b", on, key))
        self.card(title, desc, t)


class MousePage(_InputPage):
    KIND, TITLE = "pointer", "Mouse"

    def build(self, d0):
        primary = QComboBox(); primary.addItems(["Left", "Right"])
        primary.setCurrentIndex(1 if _prop(d0, "leftHanded") else 0)
        primary.currentIndexChanged.connect(lambda i: self.apply("leftHanded", "b", i == 1, "LeftHanded"))
        self.card("Primary mouse button", "", primary)
        self.card("Mouse pointer speed", "", self.speed_slider(d0))
        accel = Toggle((_prop(d0, "pointerAccelerationProfileAdaptive") or False))
        accel.toggled.connect(lambda on: (self.apply("pointerAccelerationProfileAdaptive", "b", on),
                                          self.apply("pointerAccelerationProfileFlat", "b", not on)))
        self.card("Enhance pointer precision", "", accel)
        self.section("Scrolling")
        self.toggle(d0, "naturalScroll", "NaturalScroll", "Scrolling direction: down motion scrolls up",
                    "Off = down motion scrolls down (Windows default)")
        sf = QSlider(Qt.Orientation.Horizontal if QT6 else Qt.Horizontal); sf.setRange(1, 10); sf.setFixedWidth(220)
        sf.setValue(int(round((_prop(d0, "scrollFactor") or 1.0) * 3)))
        sf.valueChanged.connect(lambda v: self.apply("scrollFactor", "d", round(v / 3, 2), "ScrollFactor"))
        self.card("Lines to scroll at a time", "", sf)


class TouchpadPage(_InputPage):
    KIND, TITLE = "touchpad", "Touchpad"

    def build(self, d0):
        on = Toggle(bool(_prop(d0, "enabled")))
        on.toggled.connect(lambda v: self.apply("enabled", "b", v))
        self.card("Touchpad", "", on)
        self.card("Cursor speed", "", self.speed_slider(d0))
        self.section("Taps")
        self.toggle(d0, "tapToClick", "TapToClick", "Tap with a single finger to single-click")
        self.toggle(d0, "lmrTapButtonMap", "LmrTapButtonMap", "Tap with two fingers to right-click",
                    "When off, two-finger tap is middle-click")
        self.toggle(d0, "tapAndDrag", "TapAndDrag", "Tap twice and drag to multi-select")
        self.toggle(d0, "disableWhileTyping", "DisableWhileTyping", "Leave touchpad on when typing is off",
                    "Ignores the touchpad while you type")
        self.section("Scroll & zoom")
        self.toggle(d0, "naturalScroll", "NaturalScroll", "Down motion scrolls up", "Windows default for touchpads: On")


# ---------------------------------------------------------------- printers --
def printers():
    res = []
    default = out(["lpstat", "-d"]).split(":")[-1].strip()
    for line in out(["lpstat", "-v"]).splitlines():
        # "device for NAME: URI"
        if line.startswith("device for "):
            name, uri = line[11:].split(":", 1)
            res.append({"name": name, "uri": uri.strip(), "default": name == default})
    return res


def lpadmin(args):
    r = run(["lpadmin", *args], timeout=60)
    if r and r.returncode == 0:
        return True
    r = elevate(["lpadmin", *args])
    return bool(r and r.returncode == 0)


class PrintersPage(Page):
    def __init__(self):
        super().__init__("Bluetooth & devices  ›  Printers & scanners")
        if not have("lpstat"):
            self.note("Printing isn't installed on this PC."); self.finish(); return
        add = QPushButton("Add device"); add.clicked.connect(self.add)
        self.card("Add a printer or scanner", "", add)
        self.list = QListWidget(); self.list.setMinimumHeight(160); self.lay.addWidget(self.list)
        row = QHBoxLayout()
        for text, fn in (("Set as default", self.make_default), ("Print test page", self.test),
                         ("Open print queue", self.queue), ("Remove", self.remove)):
            b = QPushButton(text); b.clicked.connect(fn); row.addWidget(b)
        row.addStretch(1); self.lay.addLayout(row)
        self.section("Printer preferences")
        self.auto = Toggle(kread("panes", "Printing", "LetPanesManageDefault", "false") == "true")
        self.auto.toggled.connect(lambda on: kwrite("panes", "Printing", "LetPanesManageDefault", "true" if on else "false"))
        self.card("Let Panes manage my default printer", "Default is the printer you used most recently", self.auto)
        self.finish(); self.refresh()

    def refresh(self):
        self.list.clear()
        for p in printers():
            it = QListWidgetItem(f"🖨  {p['name']}" + ("   Default" if p["default"] else ""))
            it.setData(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole, p["name"]); self.list.addItem(it)
        if not self.list.count():
            self.list.addItem("No printers yet. Select Add device.")

    def _sel(self):
        it = self.list.currentItem()
        return it.data(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole) if it else None

    def add(self):
        # Driverless printers on the network (IPP Everywhere / AirPrint), like Windows' automatic discovery.
        found = []
        for line in out(["lpinfo", "--include-schemes", "dnssd,ipp,ipps,usb", "-v"], ).splitlines():
            parts = line.split(" ", 1)
            if len(parts) == 2 and "://" in parts[1]:
                found.append(parts[1].strip())
        if have("ippfind"):
            for u in out(["ippfind", "-T", "3"]).splitlines():
                if u.strip() and u.strip() not in found:
                    found.append(u.strip())
        if not found:
            self.info("Add a printer", "No printers found. Make sure the printer is on and connected to the same network.")
            return
        labels = [u.split("://", 1)[1].split("/")[0].split("?")[0] + "  (" + u.split(":")[0].upper() + ")" for u in found]
        choice, ok = QInputDialog.getItem(self, "Add a printer", "Choose a printer", labels, 0, False)
        if not ok:
            return
        uri = found[labels.index(choice)]
        name = "".join(c if c.isalnum() else "_" for c in choice.split("  (")[0])[:40] or "Printer"
        if lpadmin(["-p", name, "-E", "-v", uri, "-m", "everywhere"]):
            self.info("Add a printer", f"{name} is ready.")
        else:
            self.error("Add a printer", "This printer couldn't be added. It may need a driver from the manufacturer.")
        self.refresh()

    def make_default(self):
        n = self._sel()
        if n:
            run(["lpoptions", "-d", n]); lpadmin(["-d", n]); self.refresh()

    def test(self):
        n = self._sel()
        page = "/usr/share/cups/data/testprint"
        if n:
            r = run(["lp", "-d", n, page if os.path.exists(page) else "/etc/hostname"])
            (self.info if r and r.returncode == 0 else self.error)("Print test page",
                "A test page has been sent to your printer." if r and r.returncode == 0 else "The test page couldn't be printed.")

    def queue(self):
        n = self._sel()
        if n:
            jobs = out(["lpstat", "-o", n]).strip()
            self.info(f"{n} - print queue", jobs or "No documents are waiting to print.")

    def remove(self):
        n = self._sel()
        if n and QMessageBox.question(self, "Remove device", "Are you sure you want to remove this device?") == \
                (QMessageBox.StandardButton.Yes if QT6 else QMessageBox.Yes):
            lpadmin(["-x", n]); self.refresh()


# ---------------------------------------------------------------- autoplay --
STATE = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "panes" / "drives.json"
CHOICES = [("Ask me every time", None), ("Open folder to view files", "open"), ("Take no action", "none")]


def _load():
    try:
        return json.loads(STATE.read_text())
    except (OSError, ValueError):
        return {}


def _store(s):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix(".tmp"); tmp.write_text(json.dumps(s, indent=1)); tmp.replace(STATE)


class AutoPlayPage(Page):
    def __init__(self):
        super().__init__("Bluetooth & devices  ›  AutoPlay")
        s = _load()
        on = Toggle(s.get("autoplay", True))
        on.toggled.connect(lambda v: self._set("autoplay", v))
        self.card("Use AutoPlay for all media and devices", "", on)
        self.section("Choose AutoPlay defaults")
        for kind, title in (("removable", "Removable drive"), ("dvd", "Memory card and discs")):
            c = QComboBox()
            for label, _v in CHOICES:
                c.addItem(label)
            c.setCurrentIndex([v for _, v in CHOICES].index(s.get("autoplay_" + kind)) if s.get("autoplay_" + kind) in ("open", "none") else 0)
            c.currentIndexChanged.connect(lambda i, k=kind: self._set("autoplay_" + k, CHOICES[i][1]))
            self.card(title, "", c)
        self.finish()

    def _set(self, key, value):
        s = _load()
        if value is None:
            s.pop(key, None)
        else:
            s[key] = value
        _store(s)
