"""Accounts: AccountsService (D-Bus) + group membership, Win11 wording."""
import grp
import os
import pwd
import shutil
from pathlib import Path

from .ui import *  # noqa: F401,F403

ADMIN_GROUPS = ("sudo", "admin", "wheel")


def is_admin(user):
    for g in ADMIN_GROUPS:
        try:
            if user in grp.getgrnam(g).gr_mem:
                return True
        except KeyError:
            pass
    return False


def acct_path(uid):
    r = out(["busctl", "--system", "call", "org.freedesktop.Accounts",
             "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
             "FindUserById", "x", str(uid)])
    # reply: o "/org/freedesktop/Accounts/User1000"
    return r.split('"')[1] if '"' in r else ""


def acct_call(uid, method, sig, *args):
    p = acct_path(uid)
    if not p:
        return False
    r = run(["busctl", "--system", "call", "org.freedesktop.Accounts", p,
             "org.freedesktop.Accounts.User", method, sig, *map(str, args)], timeout=120)
    return bool(r and r.returncode == 0)


def human_users():
    return [p for p in pwd.getpwall()
            if p.pw_uid >= 1000 and p.pw_uid < 60000
            and not p.pw_shell.endswith(("nologin", "false"))]


class AccountsPage(Page):
    def __init__(self):
        super().__init__("Accounts")
        me = pwd.getpwuid(os.getuid())
        self.me = me
        full = me.pw_gecos.split(",")[0] or me.pw_name
        self.name_lbl = QLabel("")
        self.hero = self.card(full, ("Administrator" if is_admin(me.pw_name)
                                     else "Standard user") + "  ·  Local account")
        self.section("Account settings")
        pic = QPushButton("Browse files"); pic.clicked.connect(self.picture)
        self.card("Your info", "Profile photo", pic)
        nm = QPushButton("Change name"); nm.clicked.connect(self.rename)
        self.card("Display name", "The name shown on the sign-in screen and Start", nm)
        pw = QPushButton("Change"); pw.clicked.connect(self.password)
        self.card("Sign-in options", "Password", pw)
        self.section("Other users")
        self.others = QListWidget(); self.others.setMaximumHeight(140)
        self.lay.addWidget(self.others)
        row = QHBoxLayout()
        ctype = QPushButton("Change account type"); ctype.clicked.connect(self.change_type)
        rem = QPushButton("Remove"); rem.clicked.connect(self.remove_user)
        row.addWidget(ctype); row.addWidget(rem); row.addStretch(1); self.lay.addLayout(row)
        add = QPushButton("Add account"); add.clicked.connect(self.add_user)
        self.card("Add other user", "", add)
        self.fill_others()
        self.finish()

    def rename(self):
        cur = self.hero.title_label.text()
        name, ok = QInputDialog.getText(self, "Change name", "Name", text=cur)
        if ok and name.strip():
            if acct_call(self.me.pw_uid, "SetRealName", "s", name.strip()):
                self.hero.title_label.setText(name.strip())
            else:
                self.error("Accounts", "Your name couldn't be changed.")

    def picture(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose a photo", str(Path.home() / "Pictures"),
                                              "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if not path:
            return
        dest = Path.home() / ".face.icon"
        try:
            shutil.copyfile(path, dest)
        except OSError:
            self.error("Accounts", "That photo couldn't be used."); return
        acct_call(self.me.pw_uid, "SetIconFile", "s", str(dest))
        self.info("Accounts", "Your photo was updated.")

    def password(self):
        from .more import password_dialog
        password_dialog(self)

    def fill_others(self):
        self.others.clear()
        role = Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole
        for p in human_users():
            if p.pw_uid != self.me.pw_uid:
                it = QListWidgetItem(f"{p.pw_gecos.split(',')[0] or p.pw_name}   "
                                     + ("Administrator" if is_admin(p.pw_name) else "Standard user"))
                it.setData(role, p.pw_name); self.others.addItem(it)
        if not self.others.count():
            self.others.addItem("No other users on this PC")

    def _other(self):
        it = self.others.currentItem()
        return it.data(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole) if it else None

    def add_user(self):
        from .more import add_account_dialog
        if add_account_dialog(self):
            self.fill_others()

    def change_type(self):
        from .more import set_account_type
        u = self._other()
        if not u:
            return
        kind, ok = QInputDialog.getItem(self, "Change account type", "Account type",
                                        ["Standard User", "Administrator"], 1 if is_admin(u) else 0, False)
        if ok and not set_account_type(u, kind == "Administrator"):
            self.error("Accounts", "The account type couldn't be changed.")
        self.fill_others()

    def remove_user(self):
        from .more import remove_account
        u = self._other()
        if not u:
            return
        if QMessageBox.question(self, "Delete account and data?",
                                "Deleting this person's account will remove all their data from this PC, "
                                "including items on their desktop, downloads, documents, photos, music, and "
                                "other files.") != (QMessageBox.StandardButton.Yes if QT6 else QMessageBox.Yes):
            return
        if not remove_account(u):
            self.error("Accounts", "The account couldn't be deleted. The person may be signed in.")
        self.fill_others()
