"""Gaming: Feral GameMode + MangoHud overlay + captures, applied by panes-run."""
import configparser
from pathlib import Path

from .ui import *  # noqa: F401,F403

CONF = Path.home() / ".config/panes/gaming.conf"


def load():
    c = configparser.ConfigParser()
    c.read(CONF)
    if "gaming" not in c:
        c["gaming"] = {}
    return c


def save(c):
    CONF.parent.mkdir(parents=True, exist_ok=True)
    with open(CONF, "w") as f:
        c.write(f)


class GamingPage(Page):
    def __init__(self):
        super().__init__("Gaming")
        self.c = load(); g = self.c["gaming"]
        self.section("Game Mode")
        self.gm = Toggle(g.get("gamemode", "1" if have("gamemoderun") else "0") == "1")
        self.gm.setEnabled(have("gamemoderun"))
        self.gm.toggled.connect(lambda v: self.set("gamemode", v))
        self.card("Game Mode", "Optimize your PC for play by turning things off in the background"
                  + ("" if have("gamemoderun") else ". Install Game Mode from Pane Store to use this."),
                  self.gm)
        self.section("Game Bar")
        self.ov = Toggle(g.get("overlay", "0") == "1")
        self.ov.setEnabled(have("mangohud"))
        self.ov.toggled.connect(lambda v: self.set("overlay", v))
        self.card("Performance overlay", "Show frame rate, CPU and GPU usage while you play"
                  + ("" if have("mangohud") else ". Install the performance overlay from Pane Store."),
                  self.ov)
        self.section("Captures")
        cap = Path(g.get("captures", str(Path.home() / "Videos/Captures")))
        self.cap_card = self.card("Captures location", str(cap), self._btn("Open folder", self.open_caps))
        self.card("Take screenshot", "Win+Shift+S", self._btn("Snip now",
                  lambda: launch(["spectacle", "--region"])))
        self.section("Related")
        self.card("Steam", "Play your Steam library (Windows games run automatically)",
                  self._btn("Open", lambda: launch(["steam"])))
        self.card("Graphics", "Choose the default graphics performance profile",
                  self._btn("Open", self.power))
        self.finish()

    def _btn(self, text, slot):
        b = QPushButton(text); b.clicked.connect(slot); return b

    def set(self, key, on):
        self.c["gaming"][key] = "1" if on else "0"
        save(self.c)

    def open_caps(self):
        p = Path(self.cap_card.desc_label.text())
        p.mkdir(parents=True, exist_ok=True)
        launch(["panes-explorer", str(p)])

    def power(self):
        if have("powerprofilesctl"):
            cur = out(["powerprofilesctl", "get"]).strip()
            items = ["Best performance", "Balanced", "Best power efficiency"]
            keys = ["performance", "balanced", "power-saver"]
            i = keys.index(cur) if cur in keys else 1
            choice, ok = QInputDialog.getItem(self, "Power mode", "Power mode", items, i, False)
            if ok:
                r = run(["powerprofilesctl", "set", keys[items.index(choice)]])
                if not r or r.returncode != 0:
                    self.error("Power mode", "This power mode isn't supported on this PC.")
        else:
            self.info("Power mode", "Power modes aren't available on this PC.")
