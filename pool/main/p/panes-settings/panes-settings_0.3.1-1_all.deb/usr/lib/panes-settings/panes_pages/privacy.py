"""Privacy & security: Pane Defender status, firewall, encryption,
activity history (kactivitymanagerd), app permissions (Flatpak portals)."""
import json

from .ui import *  # noqa: F401,F403

SCORING = "Plugin-org.kde.ActivityManager.Resources.Scoring"
PERMS = [("Location", "location", "location"), ("Camera", "devices", "camera"),
         ("Microphone", "devices", "microphone"), ("Screenshots", "screenshot", "screenshot")]


def flatpak_perm(table, ident):
    """Return {app_id: 'yes'/'no'} from the portal permission store."""
    res = {}
    txt = out(["flatpak", "permission-show"]) if have("flatpak") else ""
    for line in txt.splitlines()[1:]:
        cols = line.split()
        if len(cols) >= 4 and cols[0] == table and cols[1] == ident:
            res[cols[2]] = cols[3]
    return res


class PrivacyPage(Page):
    def __init__(self):
        super().__init__("Privacy & security")
        self.section("Security")
        defender = have("pane-defender")
        b = QPushButton("Open Pane Defender" if defender else "Get Pane Defender")
        b.clicked.connect(lambda: launch(["pane-defender"]) if defender else launch(["plasma-discover"]))
        self.card("Pane Defender", "Antivirus, firewall, and protection for your device"
                  if defender else "Pane Defender isn't installed yet", b)
        fw = out(["systemctl", "is-active", "ufw"]).strip() == "active"
        self.card("Firewall & network protection", "On" if fw else "Off — your PC may be exposed")
        enc = "crypt" in out(["lsblk", "-o", "TYPE", "-n"])
        self.card("Device encryption", "On" if enc else
                  "Off — choose encryption when you install Panes to protect your files")
        self.card("Find my device", "Not available on Panes")
        self.section("Panes permissions")
        self.hist = Toggle(kread("kactivitymanagerd-pluginsrc", SCORING, "what-to-remember", "0") != "2")
        self.hist.toggled.connect(self.set_history)
        clear = QPushButton("Clear history"); clear.clicked.connect(self.clear_history)
        self.card("Activity history", "Store my recent files and apps on this device", [self.hist, clear])
        self.card("Diagnostics & feedback", "Panes doesn't send diagnostic data")
        self.section("App permissions")
        for label, table, ident in PERMS:
            b = QPushButton("Manage"); b.clicked.connect(lambda _=False, l=label, t=table, i=ident:
                                                        self.manage(l, t, i))
            apps = flatpak_perm(table, ident)
            self.card(label, f"{sum(v.startswith('yes') for v in apps.values())} apps allowed"
                      if apps else "No apps have asked yet", b)
        self.finish()

    def set_history(self, on):
        kwrite("kactivitymanagerd-pluginsrc", SCORING, "what-to-remember", 0 if on else 2)

    def clear_history(self):
        for q in ("qdbus6", "qdbus"):
            if have(q):
                run([q, "org.kde.ActivityManager", "/ActivityManager/Resources/Scoring",
                     "DeleteRecentStats", "", "0", "everything"])
                break
        self.info("Activity history", "Your activity history was cleared.")

    def manage(self, label, table, ident):
        apps = flatpak_perm(table, ident)
        if not apps:
            self.info(label, "No apps have asked to use this yet."); return
        names = [f"{a}  —  {'Allowed' if v.startswith('yes') else 'Blocked'}" for a, v in apps.items()]
        choice, ok = QInputDialog.getItem(self, label, "Select an app to switch Allow / Block", names, 0, False)
        if not ok:
            return
        app = choice.split("  —  ")[0]
        new = "no" if apps[app].startswith("yes") else "yes"
        run(["flatpak", "permission-set", table, ident, app, new])
