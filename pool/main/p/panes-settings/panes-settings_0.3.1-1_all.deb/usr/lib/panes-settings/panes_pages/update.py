"""Panes Update: PackageKit (same backend as Pane Store) + unattended-upgrades.

Ubuntu's archive and security pockets are used untouched; this page only
checks, downloads, and installs what apt/PackageKit already offers.
"""
import re
from pathlib import Path

from .ui import *  # noqa: F401,F403
from .ui import elevate

AUTO = Path("/etc/apt/apt.conf.d/20auto-upgrades")


def pending():
    txt = out(["pkcon", "--plain", "--noninteractive", "get-updates"], timeout=180)
    items = []
    for line in txt.splitlines():
        m = re.match(r"\s*(Security|Normal|Important|Bug fix|Enhancement|Low|Available)\s+(\S+)", line)
        if m:
            items.append((m.group(1), m.group(2).split(";")[0]))
    return items


def history(limit=15):
    log = Path("/var/log/apt/history.log")
    rows = []
    try:
        date = ""
        for line in log.read_text(errors="ignore").splitlines():
            if line.startswith("Start-Date:"):
                date = line.split(":", 1)[1].strip()
            elif line.startswith(("Upgrade:", "Install:")):
                n = line.count("),") + 1
                rows.append(f"{date}  —  {n} update{'s' if n != 1 else ''} installed")
    except OSError:
        pass
    return rows[-limit:][::-1]


def auto_on():
    try:
        return 'Unattended-Upgrade "1"' in AUTO.read_text()
    except OSError:
        return False


class UpdatePage(Page):
    def __init__(self):
        super().__init__("Panes Update")
        self.state = self.card("You're up to date", "Last checked: not yet")
        self.check = QPushButton("Check for updates"); self.check.clicked.connect(self.do_check)
        self.install = QPushButton("Download & install all"); self.install.clicked.connect(self.do_install)
        self.install.setVisible(False)
        row = QHBoxLayout(); row.addWidget(self.check); row.addWidget(self.install); row.addStretch(1)
        self.lay.addLayout(row)
        self.list = QListWidget(); self.list.setMaximumHeight(160); self.list.setVisible(False)
        self.lay.addWidget(self.list)
        self.section("More options")
        self.auto = Toggle(auto_on()); self.auto.toggled.connect(self.set_auto)
        self.card("Get security updates automatically", "Install important security fixes in the "
                  "background (recommended)", self.auto)
        self.hist = QListWidget(); self.hist.setMaximumHeight(160)
        for r in history() or ["No updates installed yet"]:
            self.hist.addItem(r)
        self.section("Update history"); self.lay.addWidget(self.hist)
        adv = QPushButton("Open"); adv.clicked.connect(lambda: launch(["plasma-discover", "--mode", "update"]))
        self.card("Advanced options", "App updates, restart options, update sources", adv)
        self.finish()
        if not have("pkcon"):
            self.check.setEnabled(False)
            self.state.title_label.setText("Updates aren't available on this PC")

    def do_check(self):
        from datetime import datetime
        self.state.title_label.setText("Checking for updates…")
        self.check.setEnabled(False)
        QApplication.processEvents()
        run(["pkcon", "--noninteractive", "refresh"], timeout=600)
        items = pending()
        self.check.setEnabled(True)
        self.list.clear()
        for kind, pkg in items:
            name = pkg.rsplit("-", 2)[0] if pkg.count("-") >= 2 else pkg
            self.list.addItem(("Security update: " if kind == "Security" else "Update: ") + name)
        self.list.setVisible(bool(items)); self.install.setVisible(bool(items))
        self.state.title_label.setText(f"Updates available ({len(items)})" if items else "You're up to date")
        if self.state.desc_label:
            self.state.desc_label.setText("Last checked: Today, " + datetime.now().strftime("%I:%M %p").lstrip("0"))

    def do_install(self):
        self.state.title_label.setText("Installing updates…")
        r = run(["pkcon", "--noninteractive", "update"], timeout=3600)
        if r and r.returncode in (0, 5):
            needs = Path("/run/reboot-required").exists()
            self.state.title_label.setText("Restart required" if needs else "You're up to date")
            self.list.clear(); self.list.setVisible(False); self.install.setVisible(False)
        else:
            self.state.title_label.setText("There were some problems installing updates. We'll try again later.")

    def set_auto(self, on):
        v = "1" if on else "0"
        content = f'APT::Periodic::Update-Package-Lists "{v}";\\nAPT::Periodic::Unattended-Upgrade "{v}";\\n'
        r = elevate(["/bin/sh", "-c", f"printf '{content}' > {AUTO}"])
        if not r or r.returncode != 0:
            self.auto.blockSignals(True); self.auto.setChecked(not on); self.auto.blockSignals(False)
