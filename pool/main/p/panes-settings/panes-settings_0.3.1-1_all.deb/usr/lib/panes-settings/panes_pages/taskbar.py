"""Personalization > Taskbar: Plasma panel via the desktop scripting API."""
from .ui import *  # noqa: F401,F403

TASKS = "org.kde.plasma.icontasks"
SEARCH = "applications:panes-search.desktop"
TASKVIEW = "applications:panes-task-view.desktop"

READ_JS = """
var p = panels().filter(function(x){return x.location=='bottom'||x.location=='top'})[0] || panels()[0];
if (p) {
  print('align=' + p.alignment + '\\n');
  print('hiding=' + p.hiding + '\\n');
  print('location=' + p.location + '\\n');
  var t = p.widgets('%s')[0];
  if (t) { t.currentConfigGroup = ['General'];
    print('launchers=' + t.readConfig('launchers', '') + '\\n');
    print('grouping=' + t.readConfig('groupingStrategy', 1) + '\\n'); }
}
""" % TASKS


def read_state():
    st = {}
    for line in plasma_eval(READ_JS).splitlines():
        if "=" in line:
            k, v = line.split("=", 1); st[k.strip()] = v.strip()
    return st


def js_all_panels(body):
    return "panels().forEach(function(p){ %s });" % body


class TaskbarPage(Page):
    def __init__(self):
        super().__init__("Personalization  ›  Taskbar")
        st = read_state()
        self.launchers = [x for x in st.get("launchers", "").split(",") if x]
        self.section("Taskbar items")
        self.search = Toggle(SEARCH in self.launchers)
        self.search.toggled.connect(lambda v: self.pin(SEARCH, v, 0))
        self.card("Search", "", self.search)
        self.tv = Toggle(TASKVIEW in self.launchers)
        self.tv.toggled.connect(lambda v: self.pin(TASKVIEW, v, 1))
        self.card("Task view", "", self.tv)
        tray = QPushButton("Choose icons"); tray.clicked.connect(self.tray)
        self.card("Other system tray icons", "Show or hide additional system tray icons", tray)
        self.section("Taskbar behaviors")
        self.align = QComboBox(); self.align.addItems(["Center", "Left"])
        self.align.setCurrentIndex(0 if st.get("align", "center") == "center" else 1)
        self.align.activated.connect(self.set_align)
        self.card("Taskbar alignment", "", self.align)
        self.hide = Toggle(st.get("hiding", "none") in ("autohide", "dodgewindows", "windowsgobelow"))
        self.hide.toggled.connect(self.set_hide)
        self.card("Automatically hide the taskbar", "", self.hide)
        self.combine = QComboBox(); self.combine.addItems(["Always", "Never"])
        self.combine.setCurrentIndex(0 if st.get("grouping", "1") != "0" else 1)
        self.combine.activated.connect(self.set_combine)
        self.card("Combine taskbar buttons and hide labels", "", self.combine)
        self.loc = QComboBox(); self.loc.addItems(["Bottom", "Top"])
        self.loc.setCurrentIndex(1 if st.get("location") == "top" else 0)
        self.loc.activated.connect(self.set_loc)
        self.card("Taskbar location on screen", "", self.loc)
        if not st:
            self.note("Taskbar settings can't be read right now. Make sure you're signed in to the desktop.")
        self.finish()

    def _tasks(self, body):
        plasma_eval(js_all_panels(
            "p.widgets('%s').forEach(function(t){ t.currentConfigGroup=['General']; %s });" % (TASKS, body)))

    def pin(self, launcher, on, pos):
        ls = [x for x in self.launchers if x != launcher]
        if on:
            ls.insert(min(pos, len(ls)), launcher)
        self.launchers = ls
        self._tasks("t.writeConfig('launchers', %r);" % ",".join(ls))

    def set_align(self, i):
        plasma_eval(js_all_panels("p.alignment = '%s';" % ("center" if i == 0 else "left")))

    def set_hide(self, on):
        plasma_eval(js_all_panels("p.hiding = '%s';" % ("autohide" if on else "none")))

    def set_combine(self, i):
        self._tasks("t.writeConfig('groupingStrategy', %d);" % (1 if i == 0 else 0))

    def set_loc(self, i):
        plasma_eval(js_all_panels("if (p.location=='bottom'||p.location=='top') p.location = '%s';"
                                  % ("bottom" if i == 0 else "top")))

    def tray(self):
        self.info("System tray", "Right-click the arrow next to the clock and choose "
                  "Configure System Tray to show or hide icons.")
