"""Bluetooth & devices: BlueZ (bluetoothctl) backend, Win11 wording."""
import re

from .ui import *  # noqa: F401,F403


def bt(*args, timeout=15):
    return out(["bluetoothctl", *args], timeout=timeout)


def devices(kind="Paired"):
    txt = bt("devices", kind) or (bt("paired-devices") if kind == "Paired" else "")
    res = []
    for line in txt.splitlines():
        m = re.match(r"Device ([0-9A-F:]{17}) (.+)", line.strip())
        if m:
            res.append((m.group(1), m.group(2)))
    return res


def info(mac):
    d = {}
    for line in bt("info", mac).splitlines():
        if ":" in line:
            k, v = line.strip().split(":", 1)
            d[k.strip()] = v.strip()
    return d


ICON = {"audio-headset": "🎧", "audio-headphones": "🎧", "audio-card": "🔊",
        "input-mouse": "🖱", "input-keyboard": "⌨", "input-gaming": "🎮",
        "phone": "📱", "computer": "💻"}


class BluetoothPage(Page):
    def __init__(self):
        super().__init__("Bluetooth & devices")
        if not have("bluetoothctl"):
            self.note("Bluetooth isn't available on this PC.")
            self._others(); self.finish(); return
        powered = "Powered: yes" in bt("show")
        self.power = Toggle(powered); self.power.toggled.connect(self.set_power)
        self.card("Bluetooth", "Turn on to connect headphones, mice, keyboards, and more", self.power)
        self.list = QListWidget(); self.list.setMinimumHeight(150)
        self.lay.addWidget(self.list)
        row = QHBoxLayout()
        add = QPushButton("Add device"); add.clicked.connect(self.add_device)
        con = QPushButton("Connect"); con.clicked.connect(lambda: self.act("connect"))
        dis = QPushButton("Disconnect"); dis.clicked.connect(lambda: self.act("disconnect"))
        rem = QPushButton("Remove device"); rem.clicked.connect(lambda: self.act("remove"))
        for b in (add, con, dis, rem):
            row.addWidget(b)
        row.addStretch(1); self.lay.addLayout(row)
        self._others()
        self.finish()
        self.refresh()

    def _others(self):
        self.section("Related settings")
        from . import devices
        from .ui import open_page
        for title, desc, target in [
            ("Printers & scanners", "Preferences, troubleshoot", devices.PrintersPage),
            ("Mouse", "Buttons, mouse pointer speed, scrolling", devices.MousePage),
            ("Touchpad", "Taps, gestures, scrolling, zooming", devices.TouchpadPage),
            ("Cameras", "Connected cameras, default image settings", ["kamoso"]),
            ("AutoPlay", "Defaults for removable drives and memory cards", devices.AutoPlayPage),
        ]:
            b = QPushButton("Open")
            if isinstance(target, list):
                b.clicked.connect(lambda _=False, c=target: launch(c))
            else:
                b.clicked.connect(lambda _=False, t=target: open_page(self, t))
            self.card(title, desc, b)

    def refresh(self):
        self.list.clear()
        for mac, name in devices():
            i = info(mac)
            state = "Connected" if i.get("Connected") == "yes" else "Paired"
            batt = i.get("Battery Percentage", "")
            m = re.search(r"\((\d+)\)", batt)
            extra = f"  ·  {m.group(1)}%" if m else ""
            it = QListWidgetItem(f"{ICON.get(i.get('Icon',''), '🔷')}  {name}   {state}{extra}")
            it.setData(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole, mac)
            self.list.addItem(it)
        if not self.list.count():
            self.list.addItem("No devices yet. Select Add device to pair one.")

    def set_power(self, on):
        bt("power", "on" if on else "off")
        QTimer.singleShot(800, self.refresh)

    def act(self, verb):
        it = self.list.currentItem()
        mac = it.data(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole) if it else None
        if not mac:
            return
        if verb == "remove":
            if QMessageBox.question(self, "Remove device",
                                    "Are you sure you want to remove this device?") \
                    != (QMessageBox.StandardButton.Yes if QT6 else QMessageBox.Yes):
                return
        r = bt(verb, mac, timeout=30)
        if verb == "connect" and "successful" not in r:
            self.error("Bluetooth", "Couldn't connect. Make sure the device is on and in range.")
        self.refresh()

    def add_device(self):
        if not self.power.isChecked():
            self.power.setChecked(True)
        # Scan ~8s (Win11 "Add a device" also scans live).
        run(["bluetoothctl", "--timeout", "8", "scan", "on"], timeout=15)
        paired = {m for m, _ in devices()}
        found = [(m, n) for m, n in devices("") if m not in paired] or \
                [(m, n) for m, n in devices("Discovered") if m not in paired]
        names = [n for _, n in found if not re.fullmatch(r"[0-9A-F-]{17}", n)]
        if not names:
            self.info("Add a device", "No devices found. Make sure your device is on and discoverable.")
            return
        name, ok = QInputDialog.getItem(self, "Add a device", "Choose a device to pair", names, 0, False)
        if not ok:
            return
        mac = next(m for m, n in found if n == name)
        bt("pair", mac, timeout=40); bt("trust", mac); r = bt("connect", mac, timeout=30)
        if "successful" in r or info(mac).get("Paired") == "yes":
            self.info("Add a device", "Your device is ready to go!")
        else:
            self.error("Add a device", "Try connecting your device again.")
        self.refresh()
