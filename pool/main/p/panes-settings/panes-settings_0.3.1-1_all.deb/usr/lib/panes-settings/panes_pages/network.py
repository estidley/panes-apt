"""Network & internet: NetworkManager (nmcli) backend, Win11 wording."""
from .ui import *  # noqa: F401,F403


def _split(line):
    """Split nmcli -t output honoring escaped colons."""
    parts, cur, esc = [], "", False
    for ch in line:
        if esc:
            cur += ch; esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            parts.append(cur); cur = ""
        else:
            cur += ch
    parts.append(cur)
    return parts


def status():
    """Return (state_text, kind) e.g. ('Connected', 'wifi')."""
    txt = out(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION", "device"])
    for line in txt.splitlines():
        typ, state, conn = (_split(line) + ["", "", ""])[:3]
        if state == "connected" and typ in ("wifi", "ethernet"):
            return conn, typ
    return "", ""


def wifi_list():
    txt = out(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY",
               "device", "wifi", "list", "--rescan", "auto"], timeout=30)
    nets, seen = [], set()
    for line in txt.splitlines():
        inuse, ssid, sig, sec = (_split(line) + ["", "", "", ""])[:4]
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        nets.append({"active": inuse == "*", "ssid": ssid,
                     "signal": int(sig or 0), "secured": bool(sec and sec != "--")})
    return sorted(nets, key=lambda n: (not n["active"], -n["signal"]))


def bars(sig):
    return "▂▄▆█"[: max(1, min(4, (sig + 24) // 25))]


class NetworkPage(Page):
    def __init__(self):
        super().__init__("Network & internet")
        if not have("nmcli"):
            self.note("Networking service isn't available on this PC.")
            self.finish(); return
        self.status_card = self.card("Not connected", "")
        self.section("Wi-Fi")
        self.wifi = Toggle(out(["nmcli", "radio", "wifi"]).strip() == "enabled")
        self.wifi.toggled.connect(self.set_wifi)
        self.card("Wi-Fi", "Connect to wireless networks", self.wifi)
        self.list = QListWidget(); self.list.setMinimumHeight(180)
        self.lay.addWidget(self.list)
        row = QHBoxLayout()
        b_conn = QPushButton("Connect"); b_conn.clicked.connect(self.connect_sel)
        b_disc = QPushButton("Disconnect"); b_disc.clicked.connect(self.disconnect)
        b_ref = QPushButton("Refresh"); b_ref.clicked.connect(self.refresh)
        b_forget = QPushButton("Forget"); b_forget.clicked.connect(self.forget)
        for b in (b_conn, b_disc, b_forget, b_ref):
            row.addWidget(b)
        row.addStretch(1); self.lay.addLayout(row)
        self.section("More")
        air_on = out(["nmcli", "radio", "all"]).count("disabled") >= 2
        self.air = Toggle(air_on); self.air.toggled.connect(self.set_airplane)
        self.card("Airplane mode", "Stop all wireless communication", self.air)
        self.props = self.card("Properties", "", QLabel(""))
        vpn = QPushButton("Manage"); vpn.clicked.connect(self.vpn)
        self.card("VPN", "Add, connect, and manage VPN connections", vpn)
        self.proxy = QComboBox(); self.proxy.addItems(["Off", "Use setup script", "Manual"])
        self.proxy.setCurrentIndex({"0": 0, "2": 1, "1": 2}.get(
            kread("kioslaverc", "Proxy Settings", "ProxyType", "0"), 0))
        self.proxy.currentIndexChanged.connect(self.set_proxy)
        self.card("Proxy", "Proxy server for Wi-Fi and Ethernet connections", self.proxy)
        adv = QPushButton("Open"); adv.clicked.connect(self.advanced)
        self.card("Advanced network settings", "View all network adapters, network reset", adv)
        self.finish()
        self.refresh()

    def refresh(self):
        name, kind = status()
        kind_txt = {"wifi": "Wi-Fi", "ethernet": "Ethernet"}.get(kind, "")
        self.status_card.title_label.setText(
            (f"{kind_txt}: {name}\nConnected, secured" if name else
             "Not connected\nYou aren't connected to any networks"))
        ip = ""
        for line in out(["nmcli", "-t", "-f", "IP4.ADDRESS", "device", "show"]).splitlines():
            v = line.split(":", 1)[-1]
            if v and not v.startswith("127."):
                ip = v.split("/")[0]; break
        self.props.title_label.setText("Properties" + (f"  ·  IPv4 address: {ip}" if ip else ""))
        self.list.clear()
        if self.wifi.isChecked():
            for n in wifi_list():
                lock = "🔒 " if n["secured"] else ""
                tag = "   Connected" if n["active"] else ""
                it = QListWidgetItem(f"{bars(n['signal'])}  {lock}{n['ssid']}{tag}")
                it.setData(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole, n)
                self.list.addItem(it)

    def _sel(self):
        it = self.list.currentItem()
        return it.data(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole) if it else None

    def connect_sel(self):
        n = self._sel()
        if not n:
            return
        cmd = ["nmcli", "device", "wifi", "connect", n["ssid"]]
        known = n["ssid"] in out(["nmcli", "-t", "-f", "NAME", "connection"]).splitlines()
        if known:
            cmd = ["nmcli", "connection", "up", "id", n["ssid"]]
        elif n["secured"]:
            key, ok = QInputDialog.getText(self, n["ssid"], "Enter the network security key",
                                           QLineEdit.EchoMode.Password if QT6 else QLineEdit.Password)
            if not ok:
                return
            cmd += ["password", key]
        r = run(cmd, timeout=60)
        if not r or r.returncode != 0:
            self.error("Wi-Fi", f"Can't connect to {n['ssid']}. Check the security key and try again.")
        self.refresh()

    def disconnect(self):
        name, _ = status()
        if name:
            run(["nmcli", "connection", "down", "id", name])
        self.refresh()

    def forget(self):
        n = self._sel()
        if n:
            run(["nmcli", "connection", "delete", "id", n["ssid"]])
            self.refresh()

    def set_wifi(self, on):
        run(["nmcli", "radio", "wifi", "on" if on else "off"])
        QTimer.singleShot(1500, self.refresh)

    def set_airplane(self, on):
        run(["nmcli", "radio", "all", "off" if on else "on"])
        self.wifi.blockSignals(True); self.wifi.setChecked(not on); self.wifi.blockSignals(False)
        QTimer.singleShot(1500, self.refresh)

    def set_proxy(self, i):
        from .more import ProxyPage
        from .ui import open_page
        kwrite("kioslaverc", "Proxy Settings", "ProxyType", {0: 0, 1: 2, 2: 1}[i])
        if i:
            open_page(self, ProxyPage)

    def vpn(self):
        from .more import VpnPage
        from .ui import open_page
        open_page(self, VpnPage)

    def advanced(self):
        from .more import AdvancedNetworkPage
        from .ui import open_page
        open_page(self, AdvancedNetworkPage)
