"""Shared Win11-style building blocks for Panes Settings pages.

Every page talks to a real backend through run()/sh(); nothing here is
decorative. User-facing text must stay in Windows wording (no Linux jargon).
"""
from __future__ import annotations

import shutil
import subprocess

try:
    from PyQt6.QtCore import Qt, QTimer
    from PyQt6.QtGui import QFont
    from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                 QPushButton, QCheckBox, QFrame, QScrollArea,
                                 QComboBox, QSlider, QMessageBox, QInputDialog,
                                 QLineEdit, QListWidget, QListWidgetItem,
                                 QFileDialog, QApplication)
    QT6 = True
except ImportError:  # pragma: no cover
    from PyQt5.QtCore import Qt, QTimer
    from PyQt5.QtGui import QFont
    from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                 QPushButton, QCheckBox, QFrame, QScrollArea,
                                 QComboBox, QSlider, QMessageBox, QInputDialog,
                                 QLineEdit, QListWidget, QListWidgetItem,
                                 QFileDialog, QApplication)
    QT6 = False

__all__ = ["QT6", "Qt", "QTimer", "QFont", "QWidget", "QVBoxLayout", "QHBoxLayout",
           "QLabel", "QPushButton", "QCheckBox", "QFrame", "QScrollArea",
           "QComboBox", "QSlider", "QMessageBox", "QInputDialog", "QLineEdit",
           "QListWidget", "QListWidgetItem", "QFileDialog", "QApplication", "run", "out",
           "have", "plasma_eval", "Page", "Toggle", "kread", "kwrite", "elevate", "launch"]


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def run(cmd, timeout=20, input=None):
    """Run a backend command; returns CompletedProcess or None if missing."""
    try:
        return subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, input=input)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def out(cmd, timeout=20) -> str:
    r = run(cmd, timeout)
    return r.stdout if r and r.returncode == 0 else ""


def launch(cmd) -> bool:
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except FileNotFoundError:
        return False


def kread(file, group, key, default=""):
    groups = []
    for g in (group if isinstance(group, (list, tuple)) else [group]):
        groups += ["--group", g]
    for tool in ("kreadconfig6", "kreadconfig5"):
        if have(tool):
            v = out([tool, "--file", file, *groups, "--key", key,
                     "--default", str(default)]).strip()
            return v if v else str(default)
    return str(default)


def kwrite(file, group, key, value, typ=None):
    groups = []
    for g in (group if isinstance(group, (list, tuple)) else [group]):
        groups += ["--group", g]
    extra = ["--type", typ] if typ else []
    for tool in ("kwriteconfig6", "kwriteconfig5"):
        if have(tool):
            r = run([tool, "--file", file, *groups, "--key", key, *extra, str(value)])
            return bool(r and r.returncode == 0)
    return False


def elevate(cmd):
    """Admin change: goes through Panes UAC (polkit-backed)."""
    return run(["panes-uac", "--elevate", *cmd], timeout=600)


def dbus_kwin_reconfigure():
    for q in ("qdbus6", "qdbus"):
        if have(q):
            run([q, "org.kde.KWin", "/KWin", "reconfigure"])
            return


class Toggle(QCheckBox):
    """Win11 On/Off switch: label reads On/Off like Windows."""
    STYLE = ("QCheckBox::indicator{width:40px;height:20px;border-radius:10px;"
             "border:1px solid #8a8a8a;background:#fff;}"
             "QCheckBox::indicator:checked{background:#0f6cbd;border-color:#0f6cbd;}")

    def __init__(self, checked=False):
        super().__init__()
        self.setStyleSheet(self.STYLE)
        self.setChecked(checked)
        self._sync()
        self.toggled.connect(lambda _: self._sync())

    def _sync(self):
        self.setText("On" if self.isChecked() else "Off")


class Page(QScrollArea):
    """Scrollable Win11 page: breadcrumb title + stacked 'cards'."""

    def __init__(self, title: str):
        super().__init__()
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame if QT6 else QFrame.NoFrame)
        body = QWidget()
        self.lay = QVBoxLayout(body)
        self.lay.setContentsMargins(28, 20, 28, 20)
        self.lay.setSpacing(6)
        h = QLabel(title)
        f = QFont(); f.setPointSize(20); f.setBold(True); h.setFont(f)
        self.lay.addWidget(h)
        self.setWidget(body)
        self._end = None

    def section(self, text):
        lab = QLabel(text)
        f = QFont(); f.setBold(True); lab.setFont(f)
        lab.setContentsMargins(0, 14, 0, 2)
        self.lay.addWidget(lab)
        return lab

    def card(self, title, desc="", control=None):
        """One Win11 settings row: title/description left, control right."""
        fr = QFrame()
        fr.setObjectName("card")
        fr.setStyleSheet("#card{background:palette(base);border:1px solid "
                         "rgba(0,0,0,0.08);border-radius:6px;}")
        row = QHBoxLayout(fr)
        row.setContentsMargins(16, 10, 16, 10)
        col = QVBoxLayout()
        t = QLabel(title)
        col.addWidget(t)
        d = None
        if desc:
            d = QLabel(desc)
            d.setWordWrap(True)
            d.setStyleSheet("color:palette(mid);")
            col.addWidget(d)
        row.addLayout(col, 1)
        if control is not None:
            if isinstance(control, (list, tuple)):
                for c in control:
                    row.addWidget(c)
            else:
                row.addWidget(control)
        self.lay.addWidget(fr)
        fr.title_label, fr.desc_label = t, d
        return fr

    def note(self, text):
        lab = QLabel(text)
        lab.setWordWrap(True)
        self.lay.addWidget(lab)
        return lab

    def finish(self):
        self.lay.addStretch(1)

    def info(self, title, text):
        QMessageBox.information(self, title, text)

    def error(self, title, text):
        QMessageBox.warning(self, title, text)


def plasma_eval(js: str) -> str:
    """Run a Plasma desktop script (official scripting API) and return its print() output."""
    for q in ("qdbus6", "qdbus"):
        if have(q):
            r = run([q, "org.kde.plasmashell", "/PlasmaShell",
                     "org.kde.PlasmaShell.evaluateScript", js])
            return r.stdout if r and r.returncode == 0 else ""
    return ""


def open_page(parent, page_cls, *args):
    """Open a sub-page (e.g. Bluetooth & devices > Mouse) in its own Settings window."""
    try:
        from PyQt6.QtWidgets import QDialog
    except ImportError:  # pragma: no cover
        from PyQt5.QtWidgets import QDialog
    dlg = QDialog(parent)
    page = page_cls(*args)
    lay = QVBoxLayout(dlg); lay.setContentsMargins(0, 0, 0, 0); lay.addWidget(page)
    dlg.setWindowTitle("Settings"); dlg.resize(760, 620)
    dlg.exec()
    return page


__all__.append("open_page")
