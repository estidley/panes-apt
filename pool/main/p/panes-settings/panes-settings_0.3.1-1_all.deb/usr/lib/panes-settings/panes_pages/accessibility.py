"""Accessibility: KWin effects, kaccess, fonts, cursor, Orca."""
from .ui import *  # noqa: F401,F403
from .ui import dbus_kwin_reconfigure


def kwin_plugin(name):
    return kread("kwinrc", "Plugins", name + "Enabled", "false") == "true"


def set_kwin_plugin(name, on):
    kwrite("kwinrc", "Plugins", name + "Enabled", "true" if on else "false")
    dbus_kwin_reconfigure()


class AccessibilityPage(Page):
    def __init__(self):
        super().__init__("Accessibility")
        self.section("Vision")
        self.size = QSlider(Qt.Orientation.Horizontal if QT6 else Qt.Horizontal)
        self.size.setRange(100, 225); self.size.setSingleStep(5); self.size.setPageStep(25)
        dpi = int(kread("kcmfonts", "General", "forceFontDPI", "0") or 0)
        self.size.setValue(round(dpi / 96 * 100) if dpi else 100)
        self.size_lbl = QLabel(f"{self.size.value()}%")
        self.size.valueChanged.connect(lambda v: self.size_lbl.setText(f"{v}%"))
        apply = QPushButton("Apply"); apply.clicked.connect(self.apply_size)
        self.card("Text size", "Text size that appears throughout apps (sign out to apply everywhere)",
                  [self.size, self.size_lbl, apply])
        self.anim = Toggle(kread("kdeglobals", "KDE", "AnimationDurationFactor", "1") not in ("0", "0.0"))
        self.anim.toggled.connect(self.set_anim)
        self.card("Animation effects", "Visual effects", self.anim)
        self.cursor = QComboBox()
        sizes = [("Normal", 24), ("Large", 36), ("Larger", 48), ("Largest", 72)]
        for n, s in sizes:
            self.cursor.addItem(n, s)
        cur = int(kread("kcminputrc", "Mouse", "cursorSize", "24") or 24)
        self.cursor.setCurrentIndex(next((i for i, (_, s) in enumerate(sizes) if s == cur), 0))
        self.cursor.activated.connect(lambda _: kwrite("kcminputrc", "Mouse", "cursorSize",
                                                       self.cursor.currentData()))
        self.card("Mouse pointer size", "Takes effect for new windows", self.cursor)
        self.mag = Toggle(kwin_plugin("zoom")); self.mag.toggled.connect(lambda v: set_kwin_plugin("zoom", v))
        self.card("Magnifier", "Zoom in with Win+Plus, out with Win+Minus", self.mag)
        self.cf = Toggle(kwin_plugin("colorblindnesscorrection"))
        self.cf.toggled.connect(lambda v: set_kwin_plugin("colorblindnesscorrection", v))
        self.card("Color filters", "Make colors easier to tell apart", self.cf)
        self.inv = Toggle(kwin_plugin("invert")); self.inv.toggled.connect(lambda v: set_kwin_plugin("invert", v))
        self.card("Invert colors", "Toggle a window with Win+Ctrl+I, whole screen with Win+Ctrl+U", self.inv)
        self.narr = Toggle(bool(out(["pgrep", "-x", "orca"]).strip())); self.narr.setEnabled(have("orca"))
        self.narr.toggled.connect(self.set_narrator)
        self.card("Narrator", "Screen reader that describes what's on your screen"
                  + ("" if have("orca") else ". Install Narrator from Pane Store."), self.narr)
        self.section("Interaction")
        self.sticky = Toggle(kread("kaccessrc", "Keyboard", "StickyKeys", "false") == "true")
        self.sticky.toggled.connect(lambda v: self.kacc("StickyKeys", v))
        self.card("Sticky keys", "Press one key at a time for keyboard shortcuts", self.sticky)
        self.filt = Toggle(kread("kaccessrc", "Keyboard", "SlowKeys", "false") == "true")
        self.filt.toggled.connect(lambda v: self.kacc("SlowKeys", v))
        self.card("Filter keys", "Ignore brief or repeated keystrokes", self.filt)
        self.mk = Toggle(kread("kaccessrc", "Mouse", "MouseKeys", "false") == "true")
        self.mk.toggled.connect(lambda v: (kwrite("kaccessrc", "Mouse", "MouseKeys", str(v).lower()),
                                           launch(["kaccess"])))
        self.card("Mouse keys", "Use the number pad to move the mouse pointer", self.mk)
        self.finish()

    def apply_size(self):
        v = self.size.value()
        kwrite("kcmfonts", "General", "forceFontDPI", 0 if v == 100 else round(96 * v / 100))
        self.info("Text size", "Sign out and sign in again to see the new text size everywhere.")

    def set_anim(self, on):
        kwrite("kdeglobals", "KDE", "AnimationDurationFactor", "1" if on else "0")
        dbus_kwin_reconfigure()

    def kacc(self, key, on):
        kwrite("kaccessrc", "Keyboard", key, "true" if on else "false")
        launch(["kaccess"])

    def set_narrator(self, on):
        if on:
            launch(["orca"])
        else:
            run(["pkill", "-x", "orca"])
