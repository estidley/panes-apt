"""Time & language: systemd-timedated/localed + Plasma locale/keyboard."""
from datetime import datetime

from .ui import *  # noqa: F401,F403


def tdctl():
    d = {}
    for line in out(["timedatectl", "show"]).splitlines():
        if "=" in line:
            k, v = line.split("=", 1); d[k] = v
    return d


def pretty_zone(z):
    return z.replace("_", " ").replace("/", " – ")


LANGS = [("English (United States)", "en_US.UTF-8"), ("English (United Kingdom)", "en_GB.UTF-8"),
         ("Español (España)", "es_ES.UTF-8"), ("Español (México)", "es_MX.UTF-8"),
         ("Français (France)", "fr_FR.UTF-8"), ("Deutsch (Deutschland)", "de_DE.UTF-8"),
         ("Italiano (Italia)", "it_IT.UTF-8"), ("Português (Brasil)", "pt_BR.UTF-8"),
         ("Nederlands (Nederland)", "nl_NL.UTF-8"), ("Polski (Polska)", "pl_PL.UTF-8"),
         ("日本語 (日本)", "ja_JP.UTF-8"), ("한국어 (대한민국)", "ko_KR.UTF-8"),
         ("中文 (中国)", "zh_CN.UTF-8")]


class TimeLanguagePage(Page):
    def __init__(self):
        super().__init__("Time & language")
        self.section("Date & time")
        st = tdctl()
        self.clock = self.card(datetime.now().strftime("%I:%M %p").lstrip("0") + "   "
                               + datetime.now().strftime("%A, %B %d, %Y"), "")
        self.auto = Toggle(st.get("NTP") == "yes")
        self.auto.toggled.connect(self.set_auto)
        self.card("Set time automatically", "", self.auto)
        self.auto_zone = Toggle(self._geo_on())
        self.auto_zone.toggled.connect(self.set_auto_zone)
        self.card("Set time zone automatically", "", self.auto_zone)
        self.zone = QComboBox(); self.zone.setMaxVisibleItems(20)
        zones = out(["timedatectl", "list-timezones"]).split()
        for z in zones:
            self.zone.addItem(pretty_zone(z), z)
        cur = st.get("Timezone", "")
        if cur in zones:
            self.zone.setCurrentIndex(zones.index(cur))
        self.zone.activated.connect(self.set_zone)
        self.card("Time zone", "", self.zone)
        self.h24 = Toggle("2" in plasma_eval(
            "panels().forEach(p=>p.widgets('org.kde.plasma.digitalclock').concat("
            "p.widgets('org.panes.clock')).forEach(w=>"
            "{w.currentConfigGroup=['Appearance'];print(w.readConfig('use24hFormat',1))}))"))
        self.h24.toggled.connect(self.set_24h)
        self.card("Use 24-hour clock", "Shown in the taskbar", self.h24)
        self.section("Language & region")
        cur_lang = kread("plasma-localerc", "Formats", "LANG", "en_US.UTF-8")
        self.lang = QComboBox()
        for label, code in LANGS:
            self.lang.addItem(label, code)
        idx = next((i for i, (_, c) in enumerate(LANGS) if c == cur_lang), 0)
        self.lang.setCurrentIndex(idx)
        self.lang.activated.connect(self.set_lang)
        self.card("Display language", "Settings and File Explorer will appear in this language "
                  "after you sign out", self.lang)
        self.region = QComboBox()
        for label, code in LANGS:
            self.region.addItem(label.split("(")[-1].rstrip(")"), code)
        self.region.setCurrentIndex(idx)
        self.region.activated.connect(self.set_region)
        self.card("Regional format", "Dates, times, and numbers", self.region)
        self.section("Typing")
        layouts = kread("kxkbrc", "Layout", "LayoutList", "us")
        kb = QPushButton("Options"); kb.clicked.connect(self.keyboard)
        self.card("Keyboard", "Installed keyboards: " + ", ".join(l.upper() for l in layouts.split(",") if l), kb)
        self.finish()

    def keyboard(self):
        from .more import KeyboardPage
        from .ui import open_page
        open_page(self, KeyboardPage)

    def _geo_on(self):
        return False  # no location service yet (see PARITY)

    def set_auto(self, on):
        r = run(["timedatectl", "set-ntp", "true" if on else "false"], timeout=120)
        if not r or r.returncode != 0:
            self.auto.blockSignals(True); self.auto.setChecked(not on); self.auto.blockSignals(False)
            self.error("Date & time", "This setting couldn't be changed.")

    def set_auto_zone(self, on):
        if on:
            self.info("Date & time", "Automatic time zone needs location services, which aren't "
                      "available yet. Choose your time zone from the list.")
            self.auto_zone.blockSignals(True); self.auto_zone.setChecked(False); self.auto_zone.blockSignals(False)

    def set_zone(self, _i):
        z = self.zone.currentData()
        r = run(["timedatectl", "set-timezone", z], timeout=120)
        if not r or r.returncode != 0:
            self.error("Date & time", "The time zone couldn't be changed.")

    def set_24h(self, on):
        # Taskbar clock: 1 = follow region, 2 = 24-hour (Plasma digital clock).
        plasma_eval("panels().forEach(p=>p.widgets('org.kde.plasma.digitalclock').forEach(w=>"
                    "{w.currentConfigGroup=['Appearance'];w.writeConfig('use24hFormat',%d)}));"
                    "panels().forEach(p=>p.widgets('org.panes.clock').forEach(w=>"
                    "{w.currentConfigGroup=['Appearance'];w.writeConfig('use24hFormat',%d)}))"
                    % (((2 if on else 1),) * 2))

    def set_lang(self, _i):
        code = self.lang.currentData()
        kwrite("plasma-localerc", "Translations", "LANGUAGE", code.split(".")[0])
        self.info("Language", "Sign out and sign in again to see the new language.")

    def set_region(self, _i):
        code = self.region.currentData()
        kwrite("plasma-localerc", "Formats", "LANG", code)
        self.info("Regional format", "Sign out and sign in again to apply the new format everywhere.")
