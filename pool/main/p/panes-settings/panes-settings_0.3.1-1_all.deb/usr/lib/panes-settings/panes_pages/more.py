"""Native Settings sub-pages that used to open KDE windows:
password change, add/manage accounts, keyboard layouts, VPN, proxy,
advanced network, notifications. Windows wording throughout."""
from __future__ import annotations

import os
import pty
import pwd
import re
import select
import time

from .ui import *  # noqa: F401,F403
from .ui import QT6, Qt, Page, Toggle, run, out, have, kwrite, kread, elevate

try:
    from PyQt6.QtWidgets import QDialog, QFormLayout, QDialogButtonBox, QRadioButton
except ImportError:  # pragma: no cover
    from PyQt5.QtWidgets import QDialog, QFormLayout, QDialogButtonBox, QRadioButton

PW = QLineEdit.EchoMode.Password if QT6 else QLineEdit.Password
OKC = (QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel) if QT6 else \
    (QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
YES = QMessageBox.StandardButton.Yes if QT6 else QMessageBox.Yes


def _form(parent, title, rows, ok_text="OK"):
    d = QDialog(parent); d.setWindowTitle(title); f = QFormLayout(d)
    for label, w in rows:
        f.addRow(label, w) if label else f.addRow(w)
    bb = QDialogButtonBox(OKC); bb.button(QDialogButtonBox.StandardButton.Ok if QT6 else QDialogButtonBox.Ok).setText(ok_text)
    bb.accepted.connect(d.accept); bb.rejected.connect(d.reject); f.addRow(bb)
    return d


# ---------------------------------------------------------------- password --
def change_password(current, new):
    """Run passwd on a pseudo-terminal (it insists on a TTY). Returns (ok, message)."""
    pid, fd = pty.fork()
    if pid == 0:
        os.environ["LC_ALL"] = "C"
        os.execvp("passwd", ["passwd"])
    buf, answers = b"", [current, new, new]
    deadline = time.time() + 20
    while time.time() < deadline:
        r, _, _ = select.select([fd], [], [], 0.5)
        if fd in r:
            try:
                chunk = os.read(fd, 1024)
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            if buf.rstrip().lower().endswith(b"password:") and answers:
                os.write(fd, (answers.pop(0) + "\n").encode()); buf = b""
        _, status = os.waitpid(pid, os.WNOHANG)
        if _:
            text = buf.decode(errors="ignore").lower()
            if os.WEXITSTATUS(status) == 0:
                return True, "Your password was changed."
            if "authentication" in text or "incorrect" in text:
                return False, "The current password is incorrect."
            if "short" in text or "simple" in text or "palindrome" in text or "dictionary" in text or "bad password" in text:
                return False, "That password is too easy to guess. Try a longer one."
            return False, "Your password couldn't be changed."
    try:
        os.kill(pid, 9)
    except OSError:
        pass
    return False, "Your password couldn't be changed."


def password_dialog(parent):
    cur, new, again = QLineEdit(), QLineEdit(), QLineEdit()
    for w in (cur, new, again):
        w.setEchoMode(PW)
    d = _form(parent, "Change your password", [("Current password", cur), ("New password", new),
                                               ("Confirm password", again)], "Next")
    while d.exec():
        if new.text() != again.text():
            QMessageBox.warning(parent, "Change your password", "The passwords don't match."); continue
        if not new.text():
            QMessageBox.warning(parent, "Change your password", "Enter a new password."); continue
        ok, msg = change_password(cur.text(), new.text())
        (QMessageBox.information if ok else QMessageBox.warning)(parent, "Change your password", msg)
        if ok:
            return True
    return False


# ---------------------------------------------------------------- accounts --
def username_from(name):
    u = re.sub(r"[^a-z0-9]", "", name.lower().split(" ")[0])[:20] or "user"
    if not u[0].isalpha():
        u = "u" + u
    base, i = u, 2
    while True:
        try:
            pwd.getpwnam(u); u = f"{base}{i}"; i += 1
        except KeyError:
            return u


ADD_USER = r'''set -e
user="$1"; full="$2"; kind="$3"
IFS= read -r pw
useradd -m -s /bin/bash -c "$full" "$user"
printf '%s:%s\n' "$user" "$pw" | chpasswd
for g in lpadmin plugdev netdev audio video bluetooth; do getent group "$g" >/dev/null && usermod -aG "$g" "$user" || true; done
[ "$kind" = admin ] && usermod -aG sudo "$user" || true
'''


def add_account_dialog(parent):
    name, user, pw, pw2 = QLineEdit(), QLineEdit(), QLineEdit(), QLineEdit()
    pw.setEchoMode(PW); pw2.setEchoMode(PW)
    kind = QComboBox(); kind.addItems(["Standard User", "Administrator"])
    name.textChanged.connect(lambda t: user.setText(username_from(t) if t.strip() else ""))
    d = _form(parent, "Create a user for this PC", [("User name", name), ("Sign-in name", user),
                                                    ("Password", pw), ("Reenter password", pw2),
                                                    ("Account type", kind)], "Next")
    while d.exec():
        u = user.text().strip()
        if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", u):
            QMessageBox.warning(parent, "Accounts", "Sign-in names use lowercase letters and numbers."); continue
        if pw.text() != pw2.text() or not pw.text():
            QMessageBox.warning(parent, "Accounts", "The passwords don't match."); continue
        r = run(["panes-uac", "--elevate", "sh", "-c", ADD_USER, "sh", u, name.text().strip() or u,
                 "admin" if kind.currentIndex() == 1 else "standard"], timeout=600, input=pw.text() + "\n")
        if r and r.returncode == 0:
            QMessageBox.information(parent, "Accounts", f"{name.text().strip() or u} can now sign in to this PC.")
            return True
        QMessageBox.warning(parent, "Accounts", "The account couldn't be created.")
        return False
    return False


def set_account_type(user, admin):
    r = elevate(["usermod", "-aG", "sudo", user] if admin else ["gpasswd", "-d", user, "sudo"])
    return bool(r and r.returncode == 0)


def remove_account(user):
    r = elevate(["userdel", "-r", user])
    return bool(r and r.returncode == 0)


# ---------------------------------------------------------------- keyboard --
LAYOUTS = [("us", "English (United States) - US"), ("gb", "English (United Kingdom)"),
           ("us(intl)", "United States-International"), ("ca", "Canadian French"), ("de", "German"),
           ("fr", "French"), ("es", "Spanish"), ("latam", "Latin American"), ("it", "Italian"),
           ("pt", "Portuguese (Portugal)"), ("br", "Portuguese (Brazil ABNT)"), ("nl", "Dutch"),
           ("se", "Swedish"), ("no", "Norwegian"), ("dk", "Danish"), ("fi", "Finnish"), ("pl", "Polish (Programmers)"),
           ("cz", "Czech"), ("ru", "Russian"), ("ua", "Ukrainian"), ("tr", "Turkish Q"), ("gr", "Greek"),
           ("jp", "Japanese"), ("kr", "Korean"), ("cn", "Chinese"), ("in", "Hindi (India)"), ("il", "Hebrew"),
           ("ara", "Arabic")]


def _layout_label(code):
    return next((l for c, l in LAYOUTS if c == code), code.upper())


def _reload_keyboard():
    if have("dbus-send"):
        run(["dbus-send", "--session", "--type=signal", "/Layouts", "org.kde.keyboard.reloadConfig"])


class KeyboardPage(Page):
    def __init__(self):
        super().__init__("Time & language  ›  Language & region  ›  Keyboard")
        self.list = QListWidget(); self.list.setMaximumHeight(200)
        self.lay.addWidget(self.list)
        row = QHBoxLayout()
        add = QPushButton("Add a keyboard"); add.clicked.connect(self.add)
        rm = QPushButton("Remove"); rm.clicked.connect(self.remove)
        up = QPushButton("Move up"); up.clicked.connect(self.move_up)
        for b in (add, up, rm):
            row.addWidget(b)
        row.addStretch(1); self.lay.addLayout(row)
        self.section("Switching")
        self.card("Switch input language", "Windows logo key + Spacebar", QLabel(""))
        self.finish(); self.refresh()

    def layouts(self):
        lay = kread("kxkbrc", "Layout", "LayoutList", "us").split(",")
        var = kread("kxkbrc", "Layout", "VariantList", "").split(",")
        return [(l + (f"({var[i]})" if i < len(var) and var[i] else "")) for i, l in enumerate(lay) if l]

    def save(self, codes):
        lays, vars_ = [], []
        for c in codes:
            m = re.match(r"([a-z]+)(?:\((\w+)\))?", c)
            lays.append(m.group(1)); vars_.append(m.group(2) or "")
        kwrite("kxkbrc", "Layout", "LayoutList", ",".join(lays))
        kwrite("kxkbrc", "Layout", "VariantList", ",".join(vars_))
        kwrite("kxkbrc", "Layout", "Use", "true")
        kwrite("kglobalshortcutsrc", "KDE Keyboard Layout Switcher", "Switch to Next Keyboard Layout",
               "Meta+Space,none,Switch to Next Keyboard Layout")
        _reload_keyboard(); self.refresh()

    def refresh(self):
        self.list.clear()
        for c in self.layouts():
            it = QListWidgetItem("⌨  " + _layout_label(c)); it.setData(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole, c)
            self.list.addItem(it)

    def add(self):
        cur = self.layouts()
        options = [l for c, l in LAYOUTS if c not in cur]
        label, ok = QInputDialog.getItem(self, "Add a keyboard", "Choose a keyboard layout", options, 0, False)
        if ok:
            self.save(cur + [next(c for c, l in LAYOUTS if l == label)])

    def remove(self):
        cur = self.layouts(); i = self.list.currentRow()
        if 0 <= i < len(cur) and len(cur) > 1:
            del cur[i]; self.save(cur)

    def move_up(self):
        cur = self.layouts(); i = self.list.currentRow()
        if 0 < i < len(cur):
            cur[i - 1], cur[i] = cur[i], cur[i - 1]; self.save(cur)


# --------------------------------------------------------------------- VPN --
def vpns():
    res = []
    active = set(out(["nmcli", "-t", "-f", "NAME", "connection", "show", "--active"]).splitlines())
    for line in out(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"]).splitlines():
        name, _, typ = line.rpartition(":")
        if typ in ("vpn", "wireguard"):
            res.append((name.replace("\\:", ":"), name in active))
    return res


class VpnPage(Page):
    def __init__(self):
        super().__init__("Network & internet  ›  VPN")
        add = QPushButton("Add VPN"); add.clicked.connect(self.add)
        self.card("VPN connections", "", add)
        self.list = QListWidget(); self.list.setMinimumHeight(160); self.lay.addWidget(self.list)
        row = QHBoxLayout()
        for text, fn in (("Connect", self.up), ("Disconnect", self.down), ("Remove", self.remove)):
            b = QPushButton(text); b.clicked.connect(fn); row.addWidget(b)
        row.addStretch(1); self.lay.addLayout(row)
        self.note("To add a VPN, use the configuration file from your VPN provider (.ovpn or .conf).")
        self.finish(); self.refresh()

    def refresh(self):
        self.list.clear()
        for name, on in vpns():
            it = QListWidgetItem(f"🔐  {name}" + ("   Connected" if on else ""))
            it.setData(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole, name); self.list.addItem(it)
        if not self.list.count():
            self.list.addItem("No VPN connections yet.")

    def _sel(self):
        it = self.list.currentItem()
        return it.data(Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole) if it else None

    def add(self):
        path, _ = QFileDialog.getOpenFileName(self, "Add VPN", os.path.expanduser("~/Downloads"),
                                              "VPN configuration (*.ovpn *.conf)")
        if not path:
            return
        kind = "wireguard" if path.endswith(".conf") else "openvpn"
        r = run(["nmcli", "connection", "import", "type", kind, "file", path], timeout=60)
        if not r or r.returncode != 0:
            self.error("Add VPN", "This VPN couldn't be added. The VPN type may not be supported yet.")
        self.refresh()

    def up(self):
        n = self._sel()
        if n:
            r = run(["nmcli", "connection", "up", "id", n], timeout=90)
            if not r or r.returncode != 0:
                self.error("VPN", "Couldn't connect. Check your sign-in info.")
            self.refresh()

    def down(self):
        n = self._sel()
        if n:
            run(["nmcli", "connection", "down", "id", n]); self.refresh()

    def remove(self):
        n = self._sel()
        if n and QMessageBox.question(self, "VPN", f"Remove {n}?") == YES:
            run(["nmcli", "connection", "delete", "id", n]); self.refresh()


# ------------------------------------------------------------------- proxy --
class ProxyPage(Page):
    def __init__(self):
        super().__init__("Network & internet  ›  Proxy")
        self.section("Automatic proxy setup")
        self.script = QLineEdit(kread("kioslaverc", "Proxy Settings", "Proxy Config Script", ""))
        self.use_script = Toggle(kread("kioslaverc", "Proxy Settings", "ProxyType", "0") == "2")
        self.card("Use setup script", "", self.use_script)
        self.card("Script address", "", self.script)
        self.section("Manual proxy setup")
        self.use_manual = Toggle(kread("kioslaverc", "Proxy Settings", "ProxyType", "0") == "1")
        self.card("Use a proxy server", "", self.use_manual)
        cur = kread("kioslaverc", "Proxy Settings", "httpProxy", "")
        m = re.match(r"(?:\w+://)?([^ :]+)[ :]?(\d*)", cur)
        self.addr = QLineEdit(m.group(1) if m else ""); self.port = QLineEdit(m.group(2) if m else "")
        self.port.setFixedWidth(80)
        self.card("Proxy IP address", "", self.addr); self.card("Port", "", self.port)
        self.bypass = QLineEdit(kread("kioslaverc", "Proxy Settings", "NoProxyFor", "localhost,127.0.0.1"))
        self.card("Use the proxy server except for addresses that start with the following entries",
                  "Use commas (,) to separate entries", self.bypass)
        save = QPushButton("Save"); save.clicked.connect(self.save); self.lay.addWidget(save)
        self.finish()

    def save(self):
        if self.use_manual.isChecked() and self.addr.text().strip():
            host, port = self.addr.text().strip(), self.port.text().strip() or "8080"
            kwrite("kioslaverc", "Proxy Settings", "ProxyType", 1)
            for k, scheme in (("httpProxy", "http"), ("httpsProxy", "http"), ("ftpProxy", "http")):
                kwrite("kioslaverc", "Proxy Settings", k, f"{scheme}://{host} {port}")
            kwrite("kioslaverc", "Proxy Settings", "NoProxyFor", self.bypass.text().strip())
            if have("gsettings"):  # GTK apps / Firefox "use system proxy"
                run(["gsettings", "set", "org.gnome.system.proxy", "mode", "manual"])
                for s in ("http", "https", "ftp"):
                    run(["gsettings", "set", f"org.gnome.system.proxy.{s}", "host", host])
                    run(["gsettings", "set", f"org.gnome.system.proxy.{s}", "port", port])
        elif self.use_script.isChecked() and self.script.text().strip():
            kwrite("kioslaverc", "Proxy Settings", "ProxyType", 2)
            kwrite("kioslaverc", "Proxy Settings", "Proxy Config Script", self.script.text().strip())
            if have("gsettings"):
                run(["gsettings", "set", "org.gnome.system.proxy", "mode", "auto"])
                run(["gsettings", "set", "org.gnome.system.proxy", "autoconfig-url", self.script.text().strip()])
        else:
            kwrite("kioslaverc", "Proxy Settings", "ProxyType", 0)
            if have("gsettings"):
                run(["gsettings", "set", "org.gnome.system.proxy", "mode", "none"])
        if have("dbus-send"):
            run(["dbus-send", "--session", "--type=signal", "/KIO/Scheduler", "org.kde.KIO.Scheduler.reparseSlaveConfiguration", "string:"])
        self.info("Proxy", "Proxy settings saved.")


# ---------------------------------------------------------- advanced network --
class AdvancedNetworkPage(Page):
    def __init__(self):
        super().__init__("Network & internet  ›  Advanced network settings")
        self.section("Network adapters")
        for line in out(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"]).splitlines():
            dev, typ, state = (line.split(":") + ["", "", ""])[:3]
            if typ in ("loopback", "bridge", "tun", "wifi-p2p") or not dev:
                continue
            label = {"ethernet": "Ethernet", "wifi": "Wi-Fi"}.get(typ, typ.capitalize())
            t = Toggle(state not in ("unavailable", "unmanaged") and not state.startswith("disconnected") or state == "connected")
            t.setChecked(state.startswith("connected"))
            t.toggled.connect(lambda on, d=dev: run(["nmcli", "device", "connect" if on else "disconnect", d], timeout=60))
            self.card(f"{label}", "Enabled" if state.startswith("connected") else "Not connected", t)
        self.section("More settings")
        reset = QPushButton("Reset now"); reset.clicked.connect(self.reset)
        self.card("Network reset", "Turn networking off and on again", reset)
        self.finish()

    def reset(self):
        if QMessageBox.question(self, "Network reset", "Your network connections will restart. Continue?") == YES:
            run(["nmcli", "networking", "off"]); time.sleep(2); run(["nmcli", "networking", "on"])
            self.info("Network reset", "Networking has been restarted.")


# ------------------------------------------------------------ notifications --
class NotificationsPage(Page):
    def __init__(self):
        super().__init__("System  ›  Notifications")
        dnd_until = kread("plasmanotifyrc", "DoNotDisturb", "Until", "")
        self.dnd = Toggle(bool(dnd_until) and dnd_until > time.strftime("%Y-%m-%dT%H:%M:%S"))
        self.dnd.toggled.connect(self.set_dnd)
        self.card("Do not disturb", "Notifications go straight to the notification center", self.dnd)
        lock = Toggle(kread("plasmanotifyrc", "Notifications", "PopupsOnLockScreen", "false") == "true")
        lock.toggled.connect(lambda on: kwrite("plasmanotifyrc", "Notifications", "PopupsOnLockScreen", "true" if on else "false"))
        self.card("Show notifications on the lock screen", "", lock)
        snd = Toggle(kread("plasmanotifyrc", "Notifications", "PlaySounds", "true") != "false")
        snd.toggled.connect(lambda on: kwrite("plasmanotifyrc", "Notifications", "PlaySounds", "true" if on else "false"))
        self.card("Allow notifications to play sounds", "", snd)
        self.section("Notifications from apps and other senders")
        for app in self.apps():
            t = Toggle(kread("plasmanotifyrc", ["Applications", app], "ShowPopups", "true") != "false")
            t.toggled.connect(lambda on, a=app: kwrite("plasmanotifyrc", ["Applications", a], "ShowPopups", "true" if on else "false"))
            self.card(self.app_name(app), "Banners", t)
        self.finish()

    def set_dnd(self, on):
        until = "2100-01-01T00:00:00" if on else ""
        kwrite("plasmanotifyrc", "DoNotDisturb", "Until", until)

    def apps(self):
        f = os.path.expanduser("~/.config/plasmanotifyrc")
        try:
            names = re.findall(r"^\[Applications\]\[([^\]]+)\]", open(f).read(), re.M)
        except OSError:
            names = []
        return sorted(set(names))[:40]

    def app_name(self, desktop_id):
        for base in (os.path.expanduser("~/.local/share"), "/usr/share"):
            p = os.path.join(base, "applications", desktop_id + ".desktop")
            try:
                for line in open(p, errors="ignore"):
                    if line.startswith("Name="):
                        return line[5:].strip()
            except OSError:
                pass
        return desktop_id.split(".")[-1].capitalize()
