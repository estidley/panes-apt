"""Panes Settings pages (Win11 layout over real Linux backends)."""
