# panes-settings

Win11-style Settings shell. Deep links:

- `panes-settings system display`
- `panes-settings personalization background`
