#!/usr/bin/env bash
# Panes: one Win11-style desktop right-click menu.
# Win11 shows exactly one menu on empty desktop: View, Sort by, Refresh,
# Undo, New, Display settings, Personalize, Show more options. Plasma's
# desktop menu is the only menu we keep; this trims it to that shape:
#  - Folder View items (View/icons, Sort by, Refresh, Undo, New, Paste) stay
#  - Panes service menus add Display settings + Personalize
#  - KDE-only items (edit mode, Desktop and Wallpaper..., next wallpaper,
#    KRunner, terminal, lock/logout, activities, add widgets/panel) are off
# Idempotent; re-run after Plasma upgrades. Run as the desktop user.
set -euo pipefail
KW=kwriteconfig6
command -v "$KW" >/dev/null || exit 0
RC=plasma-org.kde.plasma.desktop-appletsrc
G=(--file "$RC" --group ActionPlugins --group 0 --group "RightButton;NoModifier")
set_k() { "$KW" "${G[@]}" --key "$1" "$2"; }
"$KW" --file "$RC" --group ActionPlugins --group 0 --key "RightButton;NoModifier" org.kde.contextmenu
set_k _context true
set_k _sep1 false
set_k "configure shortcuts" false
set_k _open_terminal false
set_k _run_command false
set_k "add widgets" false
set_k "_add panel" false
set_k "manage activities" false
set_k remove false
set_k "desktop edit mode" false
set_k "edit mode" false
set_k _sep2 false
set_k _lock_screen false
set_k _logout false
set_k _sep3 false
set_k _wallpaper false
set_k _sep4 false
set_k configure false
# Panes' own "Display settings" service menu replaces KDE's
# "Display Configuration" so the label matches Win11.
set_k _display_settings false
STAMP="${XDG_CONFIG_HOME:-$HOME/.config}/panes/desktop-menu.v1"
if [[ ! -e "$STAMP" ]]; then
  mkdir -p "$(dirname "$STAMP")"; touch "$STAMP"
  # Reload the shell once so the change is live without a re-login.
  if [[ "${1:-}" != "--no-reload" ]]; then
    qdbus6 org.kde.plasmashell /PlasmaShell refreshCurrentShell >/dev/null 2>&1 || true
  fi
fi
