# panes-shell

Win11-like shell helpers. Bind a mouse shortcut to `panes-desktop-menu` for desktop right-click until a custom containment ships.
Win+A → `panes-quick-settings` (via panes-defaults shortcuts).
