// Panes: taskbar pins Dolphin -> File Explorer, Konsole -> Terminal (once per user).
var swaps = {"applications:org.kde.dolphin.desktop": "applications:panes-explorer.desktop",
             "applications:org.kde.konsole.desktop": "applications:panes-terminal.desktop"};
panels().forEach(function (p) {
    p.widgets("org.kde.plasma.icontasks").concat(p.widgets("org.kde.plasma.taskmanager")).forEach(function (w) {
        w.currentConfigGroup = ["General"];
        var l = String(w.readConfig("launchers", ""));
        if (!l) return;
        var out = l.split(",").map(function (x) { return swaps[x] || x; });
        w.writeConfig("launchers", out.join(","));
        w.reloadConfig();
    });
});
