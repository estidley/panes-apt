#!/bin/sh
# Make File Explorer the default file manager for this user (runs once per user).
# Dolphin stays installed as "Dolphin (advanced)".
stamp="${XDG_CONFIG_HOME:-$HOME/.config}/panes/explorer-defaults.v1"
[ -e "$stamp" ] && exit 0
command -v xdg-mime >/dev/null && xdg-mime default panes-explorer.desktop inode/directory
if command -v kwriteconfig6 >/dev/null; then
  # Win+E opens File Explorer, not Dolphin.
  kwriteconfig6 --file kglobalshortcutsrc --group services --group org.kde.dolphin.desktop --key _launch "none"
  kwriteconfig6 --file kglobalshortcutsrc --group services --group panes-explorer.desktop --key _launch "Meta+E"
  # Plasma's "open folder" (desktop icons, notifications, Places) follows the default file manager.
  kwriteconfig6 --file kdeglobals --group General --key "TerminalApplication" "panes-terminal"
  kwriteconfig6 --file kdeglobals --group General --key "TerminalService" "panes-terminal.desktop"
  # Ask kglobalaccel to pick up the new launch shortcuts now if it is running.
  command -v qdbus6 >/dev/null && qdbus6 org.kde.kglobalaccel /kglobalaccel org.kde.KGlobalAccel.reloadConfig >/dev/null 2>&1
fi
mkdir -p "$(dirname "$stamp")" && : > "$stamp"
